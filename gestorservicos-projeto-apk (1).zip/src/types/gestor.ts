export type TabId =
  | "docs"
  | "agenda"
  | "clientes"
  | "servicos"
  | "materiais"
  | "empresa";

export type DocumentType =
  | "ORÇAMENTO"
  | "NOTA DE SERVIÇO"
  | "RECIBO DE PAGAMENTO";

export type AgendaStatus = "Agendado" | "Em Andamento" | "Concluído" | "Cancelado";

export interface CompanyProfile {
  name: string;
  doc: string;
  contact: string;
  address: string;
  pix: string;
  city: string;
  logo: string;
}

export interface ClientItem {
  id: number;
  name: string;
  doc: string;
  phone: string;
  email?: string;
  address: string;
}

export interface CatalogItem {
  id: number;
  name: string;
  unit: string;
  price: number;
}

export interface AgendaEntry {
  id: number;
  clientId: string;
  date: string;
  desc: string;
  status: AgendaStatus;
}

export interface DocItem {
  id: string;
  type: "Serviço" | "Material";
  desc: string;
  qty: number;
  price: number;
  photos?: string[];
}

export interface DocumentConfig {
  docType: DocumentType;
  clientId: string;
  payment: string;
  discount: number;
  notes: string;
}

export interface GestorState {
  company: CompanyProfile;
  clients: ClientItem[];
  services: CatalogItem[];
  materials: CatalogItem[];
  agenda: AgendaEntry[];
  docItems: DocItem[];
  docConfig: DocumentConfig;
}
