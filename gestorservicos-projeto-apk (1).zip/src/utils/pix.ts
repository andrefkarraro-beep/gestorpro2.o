export function formatarMoeda(value: number): string {
  return Number(value || 0).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

function normalizeAscii(input: string): string {
  return input
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9 .\-@/]/g, "");
}

function crc16(str: string): string {
  let crc = 0xffff;
  for (let c = 0; c < str.length; c++) {
    crc ^= str.charCodeAt(c) << 8;
    for (let i = 0; i < 8; i++) {
      crc = crc & 0x8000 ? (crc << 1) ^ 0x1021 : crc << 1;
    }
  }
  return (crc & 0xffff).toString(16).toUpperCase().padStart(4, "0");
}

function tlv(id: string, val: string): string {
  return id + String(val.length).padStart(2, "0") + val;
}

export function gerarPixPayload(
  key: string,
  name: string,
  city: string,
  amount: number
): string {
  const cleanKey = key.trim();
  if (!cleanKey) return "";

  const cleanName = (normalizeAscii(name || "RECEBEDOR").trim() || "RECEBEDOR")
    .substring(0, 25)
    .toUpperCase();
  const cleanCity = (normalizeAscii(city || "SAO PAULO").trim() || "SAO PAULO")
    .substring(0, 15)
    .toUpperCase();

  const merchant = tlv("00", "br.gov.bcb.pix") + tlv("01", cleanKey);
  let payload =
    tlv("00", "01") + tlv("26", merchant) + tlv("52", "0000") + tlv("53", "986");

  if (amount > 0) {
    payload += tlv("54", amount.toFixed(2));
  }

  payload +=
    tlv("58", "BR") +
    tlv("59", cleanName) +
    tlv("60", cleanCity) +
    tlv("62", tlv("05", "***")) +
    "6304";

  return payload + crc16(payload);
}
