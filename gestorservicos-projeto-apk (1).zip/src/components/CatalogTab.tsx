import React, { useMemo, useState } from "react";
import {
  FilePlus2,
  Package,
  Plus,
  Search,
  Trash2,
  Wrench,
} from "lucide-react";
import type { CatalogItem } from "../types/gestor";
import { formatarMoeda } from "../utils/pix";

interface CatalogTabProps {
  kind: "services" | "materials";
  items: CatalogItem[];
  onAdd: (item: CatalogItem) => void;
  onUpdatePrice: (id: number, price: number) => void;
  onDelete: (id: number) => void;
  onSendToQuote: (item: CatalogItem, kind: "services" | "materials") => void;
  onNotify: (msg: string, type?: "success" | "error") => void;
}

export const CatalogTab: React.FC<CatalogTabProps> = ({
  kind,
  items,
  onAdd,
  onUpdatePrice,
  onDelete,
  onSendToQuote,
  onNotify,
}) => {
  const isServices = kind === "services";
  const [name, setName] = useState("");
  const [unit, setUnit] = useState(isServices ? "un" : "m");
  const [price, setPrice] = useState("");
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (item) =>
        item.name.toLowerCase().includes(q) ||
        item.unit.toLowerCase().includes(q)
    );
  }, [items, search]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      onNotify(
        isServices
          ? "Informe o nome do serviço / mão de obra."
          : "Informe o nome do material.",
        "error"
      );
      return;
    }
    onAdd({
      id: Date.now(),
      name: name.trim(),
      unit: unit.trim() || "un",
      price: parseFloat(price) || 0,
    });
    setName("");
    setPrice("");
    onNotify(
      isServices
        ? "Serviço cadastrado na pasta de Mão de Obra."
        : "Material cadastrado na pasta de Materiais.",
      "success"
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            {isServices ? (
              <Wrench className="h-5 w-5 text-sky-400" />
            ) : (
              <Package className="h-5 w-5 text-emerald-400" />
            )}
            <span>
              {isServices
                ? "Pasta Mão de Obra & Serviços"
                : "Pasta Materiais & Insumos"}
            </span>
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            {isServices
              ? "Valores consultados pelo Assistente Virtual e disponíveis para adição rápida no orçamento."
              : "Peças, cabos e insumos consultados pelo Assistente Virtual para compor orçamentos."}
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={
              isServices ? "Buscar mão de obra..." : "Buscar material..."
            }
            className="min-h-[40px] w-full rounded-xl border border-slate-800 bg-[#0f172a] pl-10 pr-3.5 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
          />
        </div>
      </div>

      <form
        onSubmit={handleSubmit}
        className="rounded-2xl border border-slate-800 bg-[#0f172a] p-5"
      >
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div>
            <label
              htmlFor={`${kind}-name`}
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              {isServices ? "Nome do Serviço / Mão de Obra" : "Nome do Material"}
            </label>
            <input
              id={`${kind}-name`}
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={
                isServices
                  ? "Ex: Instalação de Disjuntor"
                  : "Ex: Cabo Flexível 2,5mm"
              }
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
            />
          </div>
          <div>
            <label
              htmlFor={`${kind}-unit`}
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Unidade
            </label>
            <input
              id={`${kind}-unit`}
              type="text"
              value={unit}
              onChange={(e) => setUnit(e.target.value)}
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
            />
          </div>
          <div>
            <label
              htmlFor={`${kind}-price`}
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              {isServices ? "Valor Mão de Obra (R$)" : "Preço Unitário (R$)"}
            </label>
            <input
              id={`${kind}-price`}
              type="number"
              step="0.01"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="0,00"
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
            />
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <button
            type="submit"
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-sky-500 px-5 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-sky-400 cursor-pointer whitespace-nowrap"
          >
            <Plus className="h-4 w-4" />
            <span>
              {isServices ? "Cadastrar Mão de Obra" : "Cadastrar Material"}
            </span>
          </button>
        </div>
      </form>

      <div className="rounded-2xl border border-slate-800 bg-[#0f172a] p-5 overflow-x-auto">
        {filtered.length === 0 ? (
          <div className="py-10 text-center">
            <p className="text-sm font-medium text-slate-300">
              Nenhum item cadastrado nesta pasta
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Adicione itens acima para que o Assistente Virtual possa consultá-los.
            </p>
          </div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="border-y border-slate-800 bg-[#030712] text-xs text-slate-400">
              <tr>
                <th className="px-3.5 py-3">
                  {isServices ? "Serviço / Mão de Obra" : "Material"}
                </th>
                <th className="px-3.5 py-3">Unidade</th>
                <th className="px-3.5 py-3 text-right">Valor (R$)</th>
                <th className="px-3.5 py-3 text-right">Orçamento</th>
                <th className="px-3.5 py-3 text-center">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filtered.map((item) => (
                <tr
                  key={item.id}
                  className="hover:bg-slate-900/50 transition-colors"
                >
                  <td className="px-3.5 py-3 font-semibold text-white">
                    {item.name}
                  </td>
                  <td className="px-3.5 py-3 text-slate-300">{item.unit}</td>
                  <td className="px-3.5 py-3 text-right">
                    <div className="inline-flex items-center gap-2">
                      <input
                        type="number"
                        step="0.01"
                        aria-label={`Valor de ${item.name}`}
                        value={item.price}
                        onChange={(e) =>
                          onUpdatePrice(
                            item.id,
                            parseFloat(e.target.value) || 0
                          )
                        }
                        className={`w-28 rounded-lg border border-slate-800 bg-[#07090e] px-2.5 py-1.5 text-right font-mono text-xs font-semibold tabular-nums focus:border-sky-500 focus:outline-none ${
                          isServices ? "text-sky-400" : "text-emerald-400"
                        }`}
                      />
                      <span className="sr-only">
                        {formatarMoeda(item.price)}
                      </span>
                    </div>
                  </td>
                  <td className="px-3.5 py-3 text-right">
                    <button
                      type="button"
                      onClick={() => onSendToQuote(item, kind)}
                      className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900 px-3 py-1 text-xs font-medium text-sky-400 hover:border-sky-500 hover:bg-slate-800 cursor-pointer whitespace-nowrap"
                    >
                      <FilePlus2 className="h-3.5 w-3.5" />
                      <span>Incluir</span>
                    </button>
                  </td>
                  <td className="px-3.5 py-3 text-center">
                    <button
                      type="button"
                      aria-label={`Excluir ${item.name}`}
                      onClick={() => onDelete(item.id)}
                      className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-rose-500/10 hover:text-rose-400 cursor-pointer"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
