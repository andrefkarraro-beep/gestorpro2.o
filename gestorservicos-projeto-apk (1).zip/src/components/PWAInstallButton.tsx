import React, { useState } from "react";
import {
  Check,
  Copy,
  Download,
  FileArchive,
  FolderDown,
  Loader2,
  Smartphone,
  Terminal,
  WifiOff,
  X,
} from "lucide-react";
import { usePWAInstall } from "../hooks/usePWAInstall";
import { useOnlineStatus } from "../hooks/useOnlineStatus";

const LOCAL_CAPACITOR_CMD =
  "npm install --legacy-peer-deps && npm run build && npm install --no-save @capacitor/core@^7.4.0 @capacitor/cli@^7.4.0 @capacitor/android@^7.4.0 && npx cap add android && npx cap sync android && cd android && ./gradlew assembleDebug";

export const PWAInstallButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showMobileModal, setShowMobileModal] = useState(false);
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [isDownloadingZip, setIsDownloadingZip] = useState(false);
  const [downloadMsg, setDownloadMsg] = useState<{
    text: string;
    type: "ok" | "err";
  } | null>(null);

  async function handleCopyCommand() {
    try {
      await navigator.clipboard.writeText(LOCAL_CAPACITOR_CMD);
      setCopiedCmd(true);
      window.setTimeout(() => setCopiedCmd(false), 2000);
    } catch {
      // Clipboard fallback ignored
    }
  }

  async function handleDownloadProjectZip() {
    if (isDownloadingZip) return;
    setIsDownloadingZip(true);
    setDownloadMsg(null);
    try {
      const apiBase = (
        (import.meta.env.VITE_API_BASE_URL as string | undefined) || ""
      ).replace(/\/+$/, "");
      const res = await fetch(`${apiBase}/api/export-project-zip`);
      if (!res.ok) {
        throw new Error("Falha ao baixar o pacote ZIP.");
      }
      const contentType = res.headers.get("content-type") || "";
      if (!contentType.includes("zip") && !contentType.includes("octet-stream")) {
        throw new Error(
          "Download indisponível offline. Abra o link web do app para baixar o pacote."
        );
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "gestorservicos-projeto-apk.zip";
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1500);
      setDownloadMsg({
        text: "Pacote gestorservicos-projeto-apk.zip baixado com todas as pastas!",
        type: "ok",
      });
    } catch (err) {
      setDownloadMsg({
        text:
          err instanceof Error
            ? err.message
            : "Não foi possível baixar o arquivo ZIP.",
        type: "err",
      });
    } finally {
      setIsDownloadingZip(false);
    }
  }

  return (
    <>
      <div className="space-y-2">
        {!isInstalled && isInstallable && (
          <button
            type="button"
            onClick={() => void install()}
            className="w-full min-h-[40px] flex items-center justify-center gap-2 rounded-xl bg-sky-500 px-3.5 py-2 text-xs font-semibold text-slate-950 transition-colors hover:bg-sky-400 cursor-pointer whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Instalar Aplicativo</span>
          </button>
        )}

        <button
          type="button"
          onClick={() => setShowMobileModal(true)}
          className="w-full min-h-[40px] flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-900 px-3.5 py-2 text-xs font-medium text-slate-200 transition-colors hover:bg-slate-800 cursor-pointer whitespace-nowrap"
        >
          <Smartphone className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
          <span>Baixar APK / Celular</span>
        </button>
      </div>

      {showMobileModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Baixar Pastas e Instalar no Celular"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-[2px]"
          onClick={() => setShowMobileModal(false)}
        >
          <div
            className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl border border-slate-800 bg-[#0f172a] p-6 text-slate-100 shadow-2xl space-y-5"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Smartphone className="h-4 w-4 text-emerald-400" />
                  <span>Baixar Pastas para APK &amp; Instalar no Celular</span>
                </h3>
                <p className="mt-1 text-xs text-slate-400">
                  Baixe o pacote completo em{" "}
                  <code className="text-emerald-400">.zip</code> para gerar o{" "}
                  <code className="text-sky-400">.apk</code> ou instale direto
                  pelo navegador.
                </p>
              </div>
              <button
                type="button"
                aria-label="Fechar"
                onClick={() => setShowMobileModal(false)}
                className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Download Direto das Pastas (.ZIP) */}
            <div className="rounded-xl border border-emerald-500/30 bg-[#07090e] p-4 space-y-3">
              <div className="flex items-center gap-2">
                <FolderDown className="h-4 w-4 text-emerald-400 shrink-0" />
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                  Passo 1 · Baixar Todas as Pastas (.ZIP)
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                O pacote inclui as pastas{" "}
                <code className="text-sky-400">src/</code>,{" "}
                <code className="text-sky-400">public/</code>,{" "}
                <code className="text-sky-400">
                  .github/workflows/build-apk.yml
                </code>{" "}
                e <code className="text-sky-400">capacitor.config.json</code>{" "}
                prontas para gerar o APK no GitHub.
              </p>
              <button
                type="button"
                onClick={() => void handleDownloadProjectZip()}
                disabled={isDownloadingZip}
                className="w-full min-h-[44px] flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-emerald-500 disabled:opacity-60 cursor-pointer"
              >
                {isDownloadingZip ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Empacotando pastas...</span>
                  </>
                ) : (
                  <>
                    <FileArchive className="h-4 w-4" />
                    <span>Baixar Pastas do Projeto (.ZIP)</span>
                  </>
                )}
              </button>

              {downloadMsg && (
                <p
                  className={`text-xs font-medium ${
                    downloadMsg.type === "ok"
                      ? "text-emerald-400"
                      : "text-rose-400"
                  }`}
                >
                  {downloadMsg.text}
                </p>
              )}
            </div>

            {/* Opção 1: Instalar direto (PWA) */}
            <div className="rounded-xl border border-slate-800 bg-[#07090e] p-4 space-y-2.5">
              <span className="text-xs font-bold uppercase tracking-wider text-sky-400 block">
                Atalho Rápido · Instalar no Celular sem APK
              </span>
              {isIOS ? (
                <ol className="space-y-1.5 text-xs text-slate-300 leading-relaxed">
                  <li>
                    1. Abra o link do app no <strong>Safari</strong> do
                    iPhone/iPad.
                  </li>
                  <li>
                    2. Toque em <strong>Compartilhar</strong> e escolha{" "}
                    <strong>Adicionar à Tela de Início</strong>.
                  </li>
                </ol>
              ) : (
                <ol className="space-y-1.5 text-xs text-slate-300 leading-relaxed">
                  <li>
                    1. Abra o link do app no <strong>Google Chrome</strong> do
                    celular.
                  </li>
                  <li>
                    2. Toque em <strong>⋮</strong> (canto superior direito) e
                    toque em <strong>Instalar aplicativo</strong>.
                  </li>
                </ol>
              )}

              {!isInstalled && isInstallable && (
                <button
                  type="button"
                  onClick={() => {
                    void install();
                    setShowMobileModal(false);
                  }}
                  className="mt-2 w-full min-h-[40px] flex items-center justify-center gap-2 rounded-xl bg-sky-500 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-sky-400 cursor-pointer"
                >
                  <Download className="h-4 w-4" />
                  <span>Instalar Agora neste Dispositivo</span>
                </button>
              )}
            </div>

            {/* Opção 2: Gerar e baixar o .apk pelo celular (GitHub Actions) */}
            <div className="rounded-xl border border-slate-800 bg-[#07090e] p-4 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 block">
                Passo 2 · Gerar e Baixar o .APK pelo Celular (GitHub)
              </span>
              <ol className="space-y-1.5 text-xs text-slate-300 leading-relaxed">
                <li>
                  1. Extraia o arquivo{" "}
                  <code className="text-emerald-400">
                    gestorservicos-projeto-apk.zip
                  </code>{" "}
                  no gerenciador de arquivos do celular.
                </li>
                <li>
                  2. Envie as pastas extraídas para um repositório no seu{" "}
                  <strong>github.com</strong>.
                </li>
                <li>
                  3. Na aba <strong>Actions</strong> do repositório, abra{" "}
                  <strong>Gerar APK Android</strong> e toque em{" "}
                  <strong>Run workflow</strong>.
                </li>
                <li>
                  4. Ao concluir, baixe o artefato{" "}
                  <strong>GestorServicos-APK</strong> e toque em{" "}
                  <code className="text-emerald-400">app-debug.apk</code> para
                  instalar.
                </li>
              </ol>

              <div className="border-t border-slate-800 pt-3 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5">
                    <Terminal className="h-3.5 w-3.5 text-slate-400" />
                    Ou compile no PC (Android Studio / JDK 21):
                  </span>
                  <button
                    type="button"
                    onClick={() => void handleCopyCommand()}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-slate-200 hover:bg-slate-700 cursor-pointer"
                  >
                    {copiedCmd ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-400" />
                        <span>Copiado</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3" />
                        <span>Copiar comando</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="overflow-x-auto rounded-lg border border-slate-800 bg-[#030712] p-2.5 text-[11px] font-mono text-slate-300">
                  {LOCAL_CAPACITOR_CMD}
                </pre>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setShowMobileModal(false)}
              className="w-full min-h-[40px] rounded-xl bg-slate-800 py-2 text-xs font-semibold text-slate-200 hover:bg-slate-700 cursor-pointer"
            >
              Fechar
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl border border-amber-500/40 bg-[#0f172a] px-3.5 py-2 text-xs font-medium text-amber-300 shadow-lg"
    >
      <WifiOff className="h-3.5 w-3.5 shrink-0" />
      <span>Modo Offline — Dados salvos localmente</span>
    </div>
  );
};
