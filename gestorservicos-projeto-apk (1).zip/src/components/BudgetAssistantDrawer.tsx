import React, { useEffect, useRef, useState } from "react";
import {
  Bot,
  Check,
  Loader2,
  Package,
  Plus,
  Send,
  Trash2,
  WifiOff,
  Wrench,
  X,
} from "lucide-react";
import type {
  CatalogItem,
  ClientItem,
  DocItem,
  DocumentConfig,
} from "../types/gestor";
import { formatarMoeda } from "../utils/pix";
import { useOnlineStatus } from "../hooks/useOnlineStatus";

interface FoundCatalogItem {
  id: number;
  folder: "Serviço" | "Material";
  name: string;
  unit: string;
  price: number;
}

interface AddedQuoteItem {
  type: "Serviço" | "Material";
  desc: string;
  qty: number;
  price: number;
}

interface AssistantMessage {
  id: string;
  role: "user" | "model";
  text: string;
  foundCatalogItems?: FoundCatalogItem[];
  addedItems?: AddedQuoteItem[];
}

interface BudgetAssistantDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  services: CatalogItem[];
  materials: CatalogItem[];
  clients: ClientItem[];
  docItems: DocItem[];
  docConfig: DocumentConfig;
  onAddItemsToQuote: (items: AddedQuoteItem[]) => void;
  onGoToDocs: () => void;
}

const STARTER_PROMPTS = [
  "Busque todos os valores na pasta de Materiais.",
  "Quais serviços de Mão de Obra estão cadastrados e seus preços?",
  "Monte uma sugestão de orçamento usando meus itens cadastrados.",
  "Qual é o resumo e o valor total do orçamento atual?",
];

export const BudgetAssistantDrawer: React.FC<BudgetAssistantDrawerProps> = ({
  isOpen,
  onClose,
  services,
  materials,
  clients,
  docItems,
  docConfig,
  onAddItemsToQuote,
  onGoToDocs,
}) => {
  const isOnline = useOnlineStatus();
  const [messages, setMessages] = useState<AssistantMessage[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [addedFeedbackIds, setAddedFeedbackIds] = useState<
    Record<string, boolean>
  >({});

  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [isOpen, onClose]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages.length, isLoading]);

  if (!isOpen) return null;

  const selectedClient =
    clients.find((c) => String(c.id) === String(docConfig.clientId)) ??
    clients[0];

  async function sendMessage(overrideText?: string) {
    const text = (overrideText ?? input).trim();
    if (!text || isLoading) return;

    if (!isOnline) {
      setError(
        "O Assistente Virtual precisa de conexão com a internet para consultar a IA."
      );
      return;
    }

    setError(null);
    if (!overrideText) setInput("");

    const userMsg: AssistantMessage = {
      id: `u-${Date.now()}`,
      role: "user",
      text,
    };
    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setIsLoading(true);

    try {
      const apiBase = (
        (import.meta.env.VITE_API_BASE_URL as string | undefined) || ""
      ).replace(/\/+$/, "");
      const res = await fetch(`${apiBase}/api/assistant/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          history: messages.map((m) => ({ role: m.role, text: m.text })),
          context: {
            services,
            materials,
            currentDoc: {
              docType: docConfig.docType,
              clientName: selectedClient?.name ?? "Cliente",
              discount: docConfig.discount,
              items: docItems.map((it) => ({
                type: it.type,
                desc: it.desc,
                qty: it.qty,
                price: it.price,
              })),
            },
          },
        }),
      });

      const contentType = res.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) {
        throw new Error(
          "Servidor do Assistente Virtual indisponível neste APK offline. Configure VITE_API_BASE_URL no build ou use a versão web conectada."
        );
      }

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Erro ao consultar o assistente.");
      }

      const addedItems = (data.addedItems ?? []) as AddedQuoteItem[];
      if (addedItems.length > 0) {
        onAddItemsToQuote(addedItems);
      }

      const botMsg: AssistantMessage = {
        id: `m-${Date.now()}`,
        role: "model",
        text: data.reply,
        foundCatalogItems: data.foundCatalogItems ?? [],
        addedItems,
      };
      setMessages([...nextMessages, botMsg]);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Falha de comunicação com o assistente."
      );
    } finally {
      setIsLoading(false);
    }
  }

  function handleQuickInclude(item: FoundCatalogItem, msgId: string) {
    onAddItemsToQuote([
      {
        type: item.folder,
        desc: item.name,
        qty: 1,
        price: item.price,
      },
    ]);
    const key = `${msgId}-${item.folder}-${item.id}`;
    setAddedFeedbackIds((prev) => ({ ...prev, [key]: true }));
    window.setTimeout(() => {
      setAddedFeedbackIds((prev) => ({ ...prev, [key]: false }));
    }, 1500);
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Assistente Virtual de Orçamento"
      className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-[1px]"
      onClick={onClose}
    >
      <aside
        onClick={(e) => e.stopPropagation()}
        className="flex h-full w-full max-w-[460px] flex-col border-l border-slate-800 bg-[#07090e] text-slate-100 shadow-2xl"
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-3 border-b border-slate-800 bg-[#030712] px-5 py-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-sky-500 text-slate-950">
              <Bot className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <h2 className="truncate text-sm font-bold text-white">
                Assistente de Orçamentos
              </h2>
              <p className="truncate text-[11px] text-slate-400">
                Consulta Materiais ({materials.length}) · Mão de Obra (
                {services.length})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {messages.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  setMessages([]);
                  setError(null);
                }}
                title="Limpar conversa"
                className="inline-flex h-9 items-center gap-1 rounded-lg px-2.5 text-xs text-slate-400 hover:bg-slate-800 hover:text-white cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Limpar</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Fechar assistente"
              className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Conversation Thread */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {!isOnline && (
            <div className="flex items-center gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-300">
              <WifiOff className="h-4 w-4 shrink-0" />
              <span>
                Sem conexão com a internet. O assistente IA voltará quando você
                estiver online.
              </span>
            </div>
          )}

          {messages.length === 0 ? (
            <div className="space-y-4">
              <div className="rounded-xl border border-slate-800 bg-[#0f172a] p-4 text-xs leading-relaxed text-slate-300">
                Posso consultar preços nas suas pastas de{" "}
                <strong className="text-emerald-400">Materiais &amp; Insumos</strong>{" "}
                e{" "}
                <strong className="text-sky-400">Mão de Obra / Serviços</strong>
                , calcular subtotais e inserir itens diretamente no seu orçamento
                atual.
              </div>

              <div className="space-y-2">
                <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Sugestões rápidas
                </p>
                {STARTER_PROMPTS.map((prompt, idx) => (
                  <button
                    key={idx}
                    type="button"
                    disabled={isLoading || !isOnline}
                    onClick={() => void sendMessage(prompt)}
                    className="block w-full rounded-xl border border-slate-800 bg-[#0f172a] px-3.5 py-2.5 text-left text-xs text-slate-200 transition-colors hover:border-sky-500/60 hover:bg-slate-900 disabled:opacity-50 cursor-pointer"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg) => {
              const isUser = msg.role === "user";
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${
                    isUser ? "items-end" : "items-start"
                  }`}
                >
                  <div
                    className={`max-w-[92%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${
                      isUser
                        ? "bg-sky-500 text-slate-950 font-medium"
                        : "border border-slate-800 bg-[#0f172a] text-slate-200"
                    }`}
                  >
                    <div className="whitespace-pre-wrap">{msg.text}</div>

                    {/* Auto-added confirmation */}
                    {msg.addedItems && msg.addedItems.length > 0 && (
                      <div className="mt-3 border-t border-slate-800 pt-2.5 space-y-1.5">
                        <div className="flex items-center justify-between text-[11px] font-semibold text-emerald-400">
                          <span>
                            Incluído no orçamento ({msg.addedItems.length}{" "}
                            {msg.addedItems.length === 1 ? "item" : "itens"})
                          </span>
                          <button
                            type="button"
                            onClick={onGoToDocs}
                            className="underline hover:text-emerald-300 cursor-pointer"
                          >
                            Ver folha A4
                          </button>
                        </div>
                        {msg.addedItems.map((it, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between gap-2 text-[11px] text-slate-300"
                          >
                            <span className="truncate">
                              {it.qty}x {it.desc}
                            </span>
                            <span className="font-mono tabular-nums shrink-0 text-slate-200">
                              {formatarMoeda(it.qty * it.price)}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Found Catalog Results with 1-click Include */}
                    {msg.foundCatalogItems &&
                      msg.foundCatalogItems.length > 0 && (
                        <div className="mt-3 border-t border-slate-800 pt-2.5 space-y-2">
                          <p className="text-[11px] font-semibold text-slate-400">
                            Itens encontrados nas pastas:
                          </p>
                          <div className="space-y-1.5">
                            {msg.foundCatalogItems.map((item) => {
                              const key = `${msg.id}-${item.folder}-${item.id}`;
                              const justAdded = Boolean(addedFeedbackIds[key]);
                              const isSrv = item.folder === "Serviço";

                              return (
                                <div
                                  key={`${item.folder}-${item.id}`}
                                  className="flex items-center justify-between gap-2 rounded-xl border border-slate-800 bg-[#07090e] px-3 py-2"
                                >
                                  <div className="min-w-0">
                                    <div className="flex items-center gap-1.5">
                                      {isSrv ? (
                                        <Wrench className="h-3 w-3 text-sky-400 shrink-0" />
                                      ) : (
                                        <Package className="h-3 w-3 text-emerald-400 shrink-0" />
                                      )}
                                      <span className="truncate text-xs font-semibold text-white">
                                        {item.name}
                                      </span>
                                    </div>
                                    <div className="mt-0.5 text-[11px] text-slate-400 font-mono tabular-nums">
                                      {isSrv ? "Mão de Obra" : "Material"} ·{" "}
                                      {formatarMoeda(item.price)} / {item.unit}
                                    </div>
                                  </div>

                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleQuickInclude(item, msg.id)
                                    }
                                    className={`inline-flex min-h-[32px] items-center gap-1 rounded-lg px-2.5 py-1 text-[11px] font-semibold transition-colors cursor-pointer shrink-0 ${
                                      justAdded
                                        ? "bg-emerald-600 text-white"
                                        : "bg-sky-500 text-slate-950 hover:bg-sky-400"
                                    }`}
                                  >
                                    {justAdded ? (
                                      <>
                                        <Check className="h-3 w-3" />
                                        <span>Incluído</span>
                                      </>
                                    ) : (
                                      <>
                                        <Plus className="h-3 w-3" />
                                        <span>Incluir</span>
                                      </>
                                    )}
                                  </button>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                  </div>
                  <span className="mt-1 px-1 text-[10px] text-slate-500">
                    {isUser ? "Você" : "Assistente GestorServiços"}
                  </span>
                </div>
              );
            })
          )}

          {isLoading && (
            <div className="flex items-start">
              <div className="inline-flex items-center gap-2 rounded-2xl border border-slate-800 bg-[#0f172a] px-4 py-2.5 text-xs text-slate-300">
                <Loader2 className="h-3.5 w-3.5 animate-spin text-sky-400" />
                <span>Consultando pastas e calculando...</span>
              </div>
            </div>
          )}

          {error && (
            <div
              role="alert"
              className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300"
            >
              {error}
            </div>
          )}

          <div ref={endRef} />
        </div>

        {/* Input Composer */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void sendMessage();
          }}
          className="border-t border-slate-800 bg-[#030712] p-3.5"
        >
          <div className="flex items-end gap-2">
            <textarea
              rows={2}
              value={input}
              disabled={isLoading || !isOnline}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  void sendMessage();
                }
              }}
              placeholder="Ex: Busque cabo 2,5mm e adicione 15m + 1 instalação..."
              className="flex-1 resize-none rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none disabled:opacity-50"
            />
            <button
              type="submit"
              aria-label="Enviar mensagem ao assistente"
              disabled={isLoading || !input.trim() || !isOnline}
              className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl bg-sky-500 text-slate-950 transition-colors hover:bg-sky-400 disabled:cursor-not-allowed disabled:opacity-45 cursor-pointer shrink-0"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </form>
      </aside>
    </div>
  );
};
