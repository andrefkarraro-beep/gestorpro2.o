import React, { useEffect, useState } from "react";
import { jsPDF } from "jspdf";
import {
  ArrowLeft,
  Download,
  FileText,
  Image as ImageIcon,
  Mail,
  MessageCircle,
  Printer,
  Share2,
  X,
} from "lucide-react";
import type { ClientItem, CompanyProfile, DocumentConfig } from "../types/gestor";
import { formatarMoeda } from "../utils/pix";

export type ExportFormat = "pdf" | "image";

interface DocumentExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  previewImageDataUrl: string;
  previewWidth: number;
  previewHeight: number;
  initialFormat?: ExportFormat;
  company: CompanyProfile;
  client?: ClientItem;
  docConfig: DocumentConfig;
  totalAmount: number;
  pixPayload: string;
  onNotify: (msg: string, type?: "success" | "error") => void;
}

export const DocumentExportModal: React.FC<DocumentExportModalProps> = ({
  isOpen,
  onClose,
  previewImageDataUrl,
  previewWidth,
  previewHeight,
  initialFormat = "pdf",
  company,
  client,
  docConfig,
  totalAmount,
  pixPayload,
  onNotify,
}) => {
  const [format, setFormat] = useState<ExportFormat>(initialFormat);
  const [recipientEmail, setRecipientEmail] = useState(client?.email ?? "");
  const [recipientPhone, setRecipientPhone] = useState(client?.phone ?? "");

  useEffect(() => {
    setFormat(initialFormat);
  }, [initialFormat, isOpen]);

  useEffect(() => {
    setRecipientEmail(client?.email ?? "");
    setRecipientPhone(client?.phone ?? "");
  }, [client?.id, client?.email, client?.phone, isOpen]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [isOpen, onClose]);

  if (!isOpen || !previewImageDataUrl) return null;

  const safeBaseName = `gestorservicos-${docConfig.docType
    .toLowerCase()
    .replace(/\s+/g, "-")}`;

  function buildPdfBlob(): Blob {
    const pdf = new jsPDF("p", "mm", "a4");
    const pdfWidth = 210;
    const pageHeight = 297;
    const totalPdfHeight =
      previewWidth > 0 ? (previewHeight * pdfWidth) / previewWidth : pageHeight;

    let heightLeft = totalPdfHeight;
    let position = 0;

    pdf.addImage(
      previewImageDataUrl,
      "JPEG",
      0,
      position,
      pdfWidth,
      totalPdfHeight
    );
    heightLeft -= pageHeight;

    while (heightLeft > 1) {
      position -= pageHeight;
      pdf.addPage();
      pdf.addImage(
        previewImageDataUrl,
        "JPEG",
        0,
        position,
        pdfWidth,
        totalPdfHeight
      );
      heightLeft -= pageHeight;
    }

    return pdf.output("blob");
  }

  async function buildImageBlob(): Promise<Blob> {
    const res = await fetch(previewImageDataUrl);
    return res.blob();
  }

  async function buildSelectedFile(): Promise<{
    file: File;
    blob: Blob;
    filename: string;
  }> {
    if (format === "pdf") {
      const blob = buildPdfBlob();
      const filename = `${safeBaseName}.pdf`;
      return {
        file: new File([blob], filename, { type: "application/pdf" }),
        blob,
        filename,
      };
    }
    const blob = await buildImageBlob();
    const filename = `${safeBaseName}.jpg`;
    return {
      file: new File([blob], filename, { type: "image/jpeg" }),
      blob,
      filename,
    };
  }

  function triggerBlobDownload(blob: Blob, filename: string) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function triggerExternalAnchor(href: string) {
    const a = document.createElement("a");
    a.href = href;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  async function handleSaveFile() {
    try {
      const { blob, filename } = await buildSelectedFile();
      triggerBlobDownload(blob, filename);
      onNotify(
        format === "pdf"
          ? "Arquivo PDF salvo com sucesso."
          : "Imagem JPG salva com sucesso.",
        "success"
      );
    } catch {
      onNotify("Não foi possível gerar o arquivo para download.", "error");
    }
  }

  async function handleSendWhatsApp() {
    try {
      const { file, blob, filename } = await buildSelectedFile();
      const clientName = client?.name ?? "Cliente";
      const summaryText = `Olá ${clientName}, segue o seu *${docConfig.docType}* emitido por *${company.name}*.\nValor total: *${formatarMoeda(totalAmount)}*${
        pixPayload ? `\n\nPix Copia e Cola:\n${pixPayload}` : ""
      }`;

      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: `${docConfig.docType} — ${company.name}`,
          text: summaryText,
          files: [file],
        });
        onNotify("Arquivo compartilhado com sucesso.", "success");
        return;
      }

      // Desktop fallback: download the selected file (PDF or JPG) and open WhatsApp Web with message
      triggerBlobDownload(blob, filename);
      const rawPhone = recipientPhone.replace(/\D/g, "");
      const phoneWithCountry =
        rawPhone && !rawPhone.startsWith("55") ? `55${rawPhone}` : rawPhone;
      const encoded = encodeURIComponent(summaryText);
      const waHref = phoneWithCountry
        ? `https://wa.me/${phoneWithCountry}?text=${encoded}`
        : `https://wa.me/?text=${encoded}`;
      triggerExternalAnchor(waHref);
      onNotify(
        `${format === "pdf" ? "PDF" : "Imagem"} baixado! Anexe o arquivo na conversa do WhatsApp.`,
        "success"
      );
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") return;
      onNotify("Não foi possível enviar pelo WhatsApp.", "error");
    }
  }

  async function handleSendEmail() {
    try {
      const { file, blob, filename } = await buildSelectedFile();
      const clientName = client?.name ?? "Cliente";
      const subject = `${docConfig.docType} - ${company.name} (${formatarMoeda(totalAmount)})`;
      const body = [
        `Olá ${clientName},`,
        "",
        `Segue o seu ${docConfig.docType} emitido por ${company.name}.`,
        `Valor total: ${formatarMoeda(totalAmount)}`,
        `Forma de pagamento: ${docConfig.payment}`,
        pixPayload ? `\nChave / Pix Copia e Cola:\n${pixPayload}` : "",
        "",
        `Atenciosamente,\n${company.name}\n${company.contact || ""}`,
      ]
        .filter(Boolean)
        .join("\n");

      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: subject,
          text: body,
          files: [file],
        });
        onNotify("Arquivo enviado para compartilhamento.", "success");
        return;
      }

      // Desktop fallback: download selected file (PDF or JPG) and launch mailto draft
      triggerBlobDownload(blob, filename);
      const targetEmail = recipientEmail.trim();
      const mailtoHref = `mailto:${encodeURIComponent(targetEmail)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      triggerExternalAnchor(mailtoHref);
      onNotify(
        `${format === "pdf" ? "PDF" : "Imagem"} baixado! Anexe o arquivo no rascunho de e-mail aberto.`,
        "success"
      );
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") return;
      onNotify("Não foi possível preparar o envio por e-mail.", "error");
    }
  }

  async function handleSystemShare() {
    try {
      const { file, blob, filename } = await buildSelectedFile();
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: `${docConfig.docType} — ${company.name}`,
          text: `Documento técnico (${formatarMoeda(totalAmount)})`,
          files: [file],
        });
      } else {
        triggerBlobDownload(blob, filename);
        onNotify(
          `${format === "pdf" ? "PDF" : "Imagem"} salvo no dispositivo.`,
          "success"
        );
      }
    } catch (err) {
      if (err instanceof Error && err.name === "AbortError") return;
      onNotify("Não foi possível compartilhar o arquivo.", "error");
    }
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Pré-visualização do Documento"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-3 sm:p-6 backdrop-blur-[2px]"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="flex h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#07090e] text-slate-100 shadow-2xl lg:flex-row"
      >
        {/* Left: Visualização da Folha A4 Renderizada */}
        <div className="flex-1 overflow-y-auto bg-[#030712] p-4 sm:p-8 flex flex-col items-center">
          <div className="mb-3 flex w-full max-w-[680px] items-center justify-between text-xs text-slate-400">
            <span>
              Pré-visualização exata ({docConfig.docType})
            </span>
            <span className="font-mono tabular-nums">
              {format === "pdf" ? "Formato PDF · A4" : "Formato Imagem · JPG"}
            </span>
          </div>

          <div className="w-full max-w-[680px] overflow-hidden rounded-lg border border-slate-700 bg-white shadow-2xl">
            <img
              src={previewImageDataUrl}
              alt={`Pré-visualização de ${docConfig.docType}`}
              className="w-full h-auto block"
            />
          </div>
        </div>

        {/* Right: Controles de Formato, Conferência e Envio */}
        <div className="flex w-full shrink-0 flex-col justify-between border-t border-slate-800 bg-[#0f172a] p-5 lg:w-[380px] lg:border-t-0 lg:border-l">
          <div className="space-y-5 overflow-y-auto">
            <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-base font-bold text-white">
                  Conferir &amp; Enviar Documento
                </h2>
                <p className="mt-1 text-xs text-slate-400">
                  Verifique a folha ao lado. Se estiver tudo certo, escolha o
                  formato e salve ou envie.
                </p>
              </div>
              <button
                type="button"
                aria-label="Fechar pré-visualização"
                onClick={onClose}
                className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Formato do Arquivo: PDF ou Imagem */}
            <div>
              <span className="mb-2 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                Formato do Arquivo
              </span>
              <div
                role="group"
                aria-label="Formato do arquivo"
                className="grid grid-cols-2 gap-1.5 rounded-xl bg-[#07090e] p-1 border border-slate-800"
              >
                <button
                  type="button"
                  onClick={() => setFormat("pdf")}
                  className={`min-h-[40px] flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold transition-colors cursor-pointer ${
                    format === "pdf"
                      ? "bg-sky-500 text-slate-950"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  <FileText className="h-4 w-4" />
                  <span>PDF (A4)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setFormat("image")}
                  className={`min-h-[40px] flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold transition-colors cursor-pointer ${
                    format === "image"
                      ? "bg-sky-500 text-slate-950"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  <ImageIcon className="h-4 w-4" />
                  <span>Imagem (JPG)</span>
                </button>
              </div>
            </div>

            {/* Dados opcionais de destino */}
            <div className="space-y-3 border-t border-slate-800 pt-4">
              <div>
                <label
                  htmlFor="exp-phone"
                  className="mb-1 block text-xs font-semibold text-slate-400"
                >
                  WhatsApp do Destinatário
                </label>
                <input
                  id="exp-phone"
                  type="text"
                  value={recipientPhone}
                  onChange={(e) => setRecipientPhone(e.target.value)}
                  placeholder="Ex: 11988887777"
                  className="min-h-[40px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3 py-2 text-xs font-mono tabular-nums text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="exp-email"
                  className="mb-1 block text-xs font-semibold text-slate-400"
                >
                  E-mail do Destinatário
                </label>
                <input
                  id="exp-email"
                  type="email"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  placeholder="cliente@email.com"
                  className="min-h-[40px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Ações de Download e Envio */}
            <div className="space-y-2.5 border-t border-slate-800 pt-4">
              <button
                type="button"
                onClick={() => void handleSaveFile()}
                className="w-full min-h-[44px] flex items-center justify-center gap-2 rounded-xl bg-sky-500 px-4 py-2.5 text-xs font-bold text-slate-950 transition-colors hover:bg-sky-400 cursor-pointer"
              >
                <Download className="h-4 w-4" />
                <span>
                  {format === "pdf"
                    ? "Salvar / Baixar PDF"
                    : "Salvar / Baixar Imagem"}
                </span>
              </button>

              <button
                type="button"
                onClick={() => void handleSendWhatsApp()}
                className="w-full min-h-[44px] flex items-center justify-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-emerald-500 cursor-pointer"
              >
                <MessageCircle className="h-4 w-4" />
                <span>
                  Enviar {format === "pdf" ? "PDF" : "Imagem"} no WhatsApp
                </span>
              </button>

              <button
                type="button"
                onClick={() => void handleSendEmail()}
                className="w-full min-h-[44px] flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800 px-4 py-2.5 text-xs font-bold text-white transition-colors hover:bg-slate-700 cursor-pointer"
              >
                <Mail className="h-4 w-4 text-sky-400" />
                <span>
                  Enviar {format === "pdf" ? "PDF" : "Imagem"} por E-mail
                </span>
              </button>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => void handleSystemShare()}
                  className="min-h-[40px] flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-[#07090e] px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-800 cursor-pointer"
                >
                  <Share2 className="h-3.5 w-3.5" />
                  <span>Compartilhar</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="min-h-[40px] flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-[#07090e] px-3 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-800 cursor-pointer"
                >
                  <Printer className="h-3.5 w-3.5" />
                  <span>Imprimir</span>
                </button>
              </div>
            </div>
          </div>

          <div className="mt-4 border-t border-slate-800 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="w-full min-h-[40px] flex items-center justify-center gap-2 rounded-xl border border-slate-700 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-slate-800 cursor-pointer"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Voltar e Editar Documento</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
