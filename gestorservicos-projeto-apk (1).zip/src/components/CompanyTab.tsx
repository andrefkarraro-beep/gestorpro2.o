import React, { useState } from "react";
import { Building2, Save, Trash2 } from "lucide-react";
import type { CompanyProfile } from "../types/gestor";

interface CompanyTabProps {
  company: CompanyProfile;
  onSave: (profile: CompanyProfile) => void;
  onNotify: (msg: string, type?: "success" | "error") => void;
}

export const CompanyTab: React.FC<CompanyTabProps> = ({
  company,
  onSave,
  onNotify,
}) => {
  const [form, setForm] = useState<CompanyProfile>(company);

  function handleLogoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const logo = typeof reader.result === "string" ? reader.result : "";
      const next = { ...form, logo };
      setForm(next);
      onSave(next);
      onNotify("Logotipo atualizado no documento A4.", "success");
    };
    reader.readAsDataURL(file);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    onSave(form);
    onNotify("Dados da empresa salvos com sucesso.", "success");
  }

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-800 pb-5">
        <h1 className="text-xl font-bold text-white flex items-center gap-2">
          <Building2 className="h-5 w-5 text-sky-400" />
          <span>Dados da Empresa &amp; Identidade Profissional</span>
        </h1>
        <p className="mt-1 text-xs text-slate-400">
          Essas informações aparecem no cabeçalho dos seus orçamentos, recibos e
          no QR Code Pix.
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="rounded-2xl border border-slate-800 bg-[#0f172a] p-6 space-y-6"
      >
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label
              htmlFor="comp-name"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Nome / Marca Profissional
            </label>
            <input
              id="comp-name"
              type="text"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="comp-doc"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              CPF / CNPJ
            </label>
            <input
              id="comp-doc"
              type="text"
              value={form.doc}
              onChange={(e) => setForm({ ...form, doc: e.target.value })}
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="comp-contact"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Contato / WhatsApp
            </label>
            <input
              id="comp-contact"
              type="text"
              value={form.contact}
              onChange={(e) => setForm({ ...form, contact: e.target.value })}
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="comp-address"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Endereço Profissional
            </label>
            <input
              id="comp-address"
              type="text"
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="comp-pix"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Chave Pix (Recebimento)
            </label>
            <input
              id="comp-pix"
              type="text"
              value={form.pix}
              onChange={(e) => setForm({ ...form, pix: e.target.value })}
              placeholder="CPF, CNPJ, E-mail, Telefone ou Aleatória"
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="comp-city"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Cidade (para BR Code Pix)
            </label>
            <input
              id="comp-city"
              type="text"
              value={form.city}
              onChange={(e) => setForm({ ...form, city: e.target.value })}
              placeholder="SAO PAULO"
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="border-t border-slate-800 pt-5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            {form.logo && (
              <img
                src={form.logo}
                alt="Logotipo da empresa"
                className="h-14 w-auto rounded-lg border border-slate-700 bg-white p-1.5 object-contain"
              />
            )}
            <div>
              <label
                htmlFor="comp-logo"
                className="mb-1.5 block text-xs font-semibold text-slate-400"
              >
                Logotipo da Empresa
              </label>
              <div className="flex flex-wrap items-center gap-2">
                <input
                  id="comp-logo"
                  type="file"
                  accept="image/*"
                  onChange={handleLogoChange}
                  className="text-xs text-slate-300 file:mr-3 file:rounded-lg file:border-0 file:bg-sky-500 file:px-3 file:py-1.5 file:text-xs file:font-semibold file:text-slate-950 hover:file:bg-sky-400 cursor-pointer"
                />
                {form.logo && (
                  <button
                    type="button"
                    onClick={() => {
                      const next = { ...form, logo: "" };
                      setForm(next);
                      onSave(next);
                    }}
                    className="inline-flex min-h-[34px] items-center gap-1 rounded-lg border border-slate-700 px-2.5 py-1 text-xs text-slate-300 hover:text-rose-400 cursor-pointer"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    <span>Remover</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-sky-500 px-5 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-sky-400 cursor-pointer whitespace-nowrap"
          >
            <Save className="h-4 w-4" />
            <span>Salvar Dados da Empresa</span>
          </button>
        </div>
      </form>
    </div>
  );
};
