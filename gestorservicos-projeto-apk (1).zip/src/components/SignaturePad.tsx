import React, { useEffect, useRef } from "react";
import { Eraser } from "lucide-react";

interface SignaturePadProps {
  signatureDataUrl: string;
  onChange: (dataUrl: string) => void;
}

function exportDarkInkSignature(sourceCanvas: HTMLCanvasElement): string {
  const offscreen = document.createElement("canvas");
  offscreen.width = sourceCanvas.width;
  offscreen.height = sourceCanvas.height;
  const ctx = offscreen.getContext("2d");
  if (!ctx) return "";

  ctx.drawImage(sourceCanvas, 0, 0);
  const imgData = ctx.getImageData(0, 0, offscreen.width, offscreen.height);
  const data = imgData.data;

  // Convert light screen strokes into dark #0f172a ink on transparent background for white A4 paper
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] > 0) {
      data[i] = 15;
      data[i + 1] = 23;
      data[i + 2] = 42;
    }
  }
  ctx.putImageData(imgData, 0, 0);
  return offscreen.toDataURL("image/png");
}

export const SignaturePad: React.FC<SignaturePadProps> = ({
  signatureDataUrl,
  onChange,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawingRef = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = 2.4;
    ctx.strokeStyle = "#f8fafc";

    if (!signatureDataUrl) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
  }, [signatureDataUrl]);

  function getPoint(e: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  }

  function handlePointerDown(e: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.setPointerCapture(e.pointerId);
    drawingRef.current = true;
    const pt = getPoint(e);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineWidth = 2.4;
    ctx.strokeStyle = "#f8fafc";
    ctx.beginPath();
    ctx.moveTo(pt.x, pt.y);
  }

  function handlePointerMove(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!drawingRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const pt = getPoint(e);
    ctx.lineTo(pt.x, pt.y);
    ctx.stroke();
  }

  function handlePointerUp(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!drawingRef.current) return;
    drawingRef.current = false;
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (canvas.hasPointerCapture(e.pointerId)) {
      canvas.releasePointerCapture(e.pointerId);
    }
    onChange(exportDarkInkSignature(canvas));
  }

  function clearCanvas() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    onChange("");
  }

  return (
    <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row sm:items-end gap-4">
      <div className="flex-1">
        <label className="block text-xs font-semibold text-slate-400 mb-1.5">
          Assinatura Digital do Responsável
        </label>
        <canvas
          ref={canvasRef}
          width={360}
          height={78}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="w-full h-[78px] rounded-xl border border-slate-800 bg-[#07090e] cursor-crosshair touch-none"
        />
      </div>
      <button
        type="button"
        onClick={clearCanvas}
        className="inline-flex min-h-[40px] items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800/80 px-3.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:bg-slate-700 cursor-pointer whitespace-nowrap shrink-0"
      >
        <Eraser className="h-3.5 w-3.5" />
        <span>Limpar Assinatura</span>
      </button>
    </div>
  );
};
