import React, { useMemo, useState } from "react";
import { Search, Trash2, UserPlus, Users } from "lucide-react";
import type { ClientItem } from "../types/gestor";

interface ClientsTabProps {
  clients: ClientItem[];
  onAdd: (client: ClientItem) => void;
  onDelete: (id: number) => void;
  onNotify: (msg: string, type?: "success" | "error") => void;
}

export const ClientsTab: React.FC<ClientsTabProps> = ({
  clients,
  onAdd,
  onDelete,
  onNotify,
}) => {
  const [name, setName] = useState("");
  const [doc, setDoc] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return clients;
    return clients.filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.doc.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        (c.email ?? "").toLowerCase().includes(q)
    );
  }, [clients, search]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      onNotify("Informe o nome ou razão social do cliente.", "error");
      return;
    }
    onAdd({
      id: Date.now(),
      name: name.trim(),
      doc: doc.trim(),
      phone: phone.trim(),
      email: email.trim(),
      address: address.trim(),
    });
    setName("");
    setDoc("");
    setPhone("");
    setEmail("");
    setAddress("");
    onNotify("Cliente cadastrado com sucesso.", "success");
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <Users className="h-5 w-5 text-sky-400" />
            <span>Cadastro de Clientes</span>
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Gerencie contatos, WhatsApp e e-mail para preenchimento e envio
            rápido de documentos.
          </p>
        </div>

        <div className="relative w-full sm:w-72">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar cliente, documento ou e-mail..."
            className="min-h-[40px] w-full rounded-xl border border-slate-800 bg-[#0f172a] pl-10 pr-3.5 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
          />
        </div>
      </div>

      <form
        onSubmit={handleSubmit}
        className="rounded-2xl border border-slate-800 bg-[#0f172a] p-5"
      >
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <div>
            <label
              htmlFor="cli-name"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Nome / Razão Social
            </label>
            <input
              id="cli-name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nome completo ou empresa"
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
            />
          </div>
          <div>
            <label
              htmlFor="cli-doc"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              CPF / CNPJ
            </label>
            <input
              id="cli-doc"
              type="text"
              value={doc}
              onChange={(e) => setDoc(e.target.value)}
              placeholder="000.000.000-00"
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
            />
          </div>
          <div>
            <label
              htmlFor="cli-phone"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Telefone / WhatsApp
            </label>
            <input
              id="cli-phone"
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Ex: 11988887777"
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
            />
          </div>
          <div>
            <label
              htmlFor="cli-email"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              E-mail
            </label>
            <input
              id="cli-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="cliente@email.com"
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
            />
          </div>
          <div>
            <label
              htmlFor="cli-address"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Endereço Completo
            </label>
            <input
              id="cli-address"
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Rua, número, bairro"
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
            />
          </div>
        </div>
        <div className="mt-4 flex justify-end">
          <button
            type="submit"
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-sky-500 px-5 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-sky-400 cursor-pointer whitespace-nowrap"
          >
            <UserPlus className="h-4 w-4" />
            <span>Salvar Cliente</span>
          </button>
        </div>
      </form>

      <div className="rounded-2xl border border-slate-800 bg-[#0f172a] p-5 overflow-x-auto">
        {filtered.length === 0 ? (
          <div className="py-10 text-center">
            <p className="text-sm font-medium text-slate-300">
              Nenhum cliente encontrado
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Cadastre um cliente acima para vinculá-lo aos seus documentos.
            </p>
          </div>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="border-y border-slate-800 bg-[#030712] text-xs text-slate-400">
              <tr>
                <th className="px-3.5 py-3">Nome</th>
                <th className="px-3.5 py-3">Documento</th>
                <th className="px-3.5 py-3">WhatsApp</th>
                <th className="px-3.5 py-3">E-mail</th>
                <th className="px-3.5 py-3">Endereço</th>
                <th className="px-3.5 py-3 text-center">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filtered.map((client) => (
                <tr
                  key={client.id}
                  className="hover:bg-slate-900/50 transition-colors"
                >
                  <td className="px-3.5 py-3 font-semibold text-white">
                    {client.name}
                  </td>
                  <td className="px-3.5 py-3 font-mono text-xs text-slate-300 tabular-nums">
                    {client.doc || "-"}
                  </td>
                  <td className="px-3.5 py-3 font-mono text-xs text-slate-300 tabular-nums">
                    {client.phone || "-"}
                  </td>
                  <td className="px-3.5 py-3 text-xs text-slate-300">
                    {client.email || "-"}
                  </td>
                  <td className="px-3.5 py-3 text-slate-300">
                    {client.address || "-"}
                  </td>
                  <td className="px-3.5 py-3 text-center">
                    <button
                      type="button"
                      aria-label={`Excluir cliente ${client.name}`}
                      onClick={() => onDelete(client.id)}
                      className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-rose-500/10 hover:text-rose-400 cursor-pointer"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
