import React from "react";
import {
  Zap,
  FileText,
  CalendarDays,
  Users,
  Wrench,
  Package,
  Building2,
  Bot,
} from "lucide-react";
import type { TabId } from "../types/gestor";
import { PWAInstallButton } from "./PWAInstallButton";

interface SidebarProps {
  activeTab: TabId;
  onSelectTab: (tab: TabId) => void;
  onOpenAssistant: () => void;
  counts: {
    agendaPending: number;
    clients: number;
    services: number;
    materials: number;
  };
}

const NAV_ITEMS: Array<{
  id: TabId;
  label: string;
  icon: React.FC<{ className?: string }>;
}> = [
  { id: "docs", label: "Orçamentos & Recibos", icon: FileText },
  { id: "agenda", label: "Agenda Técnica", icon: CalendarDays },
  { id: "clientes", label: "Clientes", icon: Users },
  { id: "servicos", label: "Mão de Obra / Serviços", icon: Wrench },
  { id: "materiais", label: "Materiais & Insumos", icon: Package },
  { id: "empresa", label: "Dados da Empresa", icon: Building2 },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  onOpenAssistant,
  counts,
}) => {
  function getCount(id: TabId): number | null {
    if (id === "agenda" && counts.agendaPending > 0) return counts.agendaPending;
    if (id === "clientes") return counts.clients;
    if (id === "servicos") return counts.services;
    if (id === "materiais") return counts.materials;
    return null;
  }

  return (
    <aside className="w-full md:w-64 bg-[#030712] border-b md:border-b-0 md:border-r border-slate-800 flex flex-col shrink-0">
      {/* Brand Zone */}
      <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-sky-500 flex items-center justify-center shrink-0">
            <Zap className="h-5 w-5 text-slate-950 fill-current" />
          </div>
          <span className="font-extrabold text-lg tracking-tight text-white whitespace-nowrap shrink-0">
            Gestor<span className="text-sky-400">Serviços</span>
          </span>
        </div>

        <button
          type="button"
          onClick={onOpenAssistant}
          aria-label="Abrir Assistente Virtual"
          className="md:hidden inline-flex min-h-[38px] items-center gap-1.5 rounded-xl bg-sky-500/15 border border-sky-500/40 px-3 py-1.5 text-xs font-semibold text-sky-300 cursor-pointer whitespace-nowrap"
        >
          <Bot className="h-4 w-4" />
          <span>Assistente</span>
        </button>
      </div>

      {/* Navigation */}
      <nav
        aria-label="Menu principal"
        className="p-3 flex md:flex-col gap-1.5 overflow-x-auto md:overflow-y-auto flex-1"
      >
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          const count = getCount(item.id);

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`min-h-[42px] flex items-center justify-between gap-2.5 px-3.5 py-2.5 rounded-xl text-sm transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer ${
                active
                  ? "bg-sky-500 text-slate-950 font-semibold"
                  : "text-slate-400 font-medium hover:bg-slate-900 hover:text-slate-100"
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Icon className="h-4 w-4 shrink-0" />
                <span>{item.label}</span>
              </span>
              {count !== null && (
                <span
                  className={`font-mono text-xs tabular-nums ${
                    active ? "text-slate-950/80" : "text-slate-500"
                  }`}
                >
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Sidebar Bottom Actions: Virtual Assistant + PWA Install */}
      <div className="p-3 border-t border-slate-800 space-y-2">
        <button
          type="button"
          onClick={onOpenAssistant}
          className="hidden md:flex w-full min-h-[42px] items-center justify-center gap-2 rounded-xl border border-sky-500/40 bg-sky-500/10 px-3.5 py-2 text-xs font-semibold text-sky-300 transition-colors hover:bg-sky-500/20 cursor-pointer whitespace-nowrap"
        >
          <Bot className="h-4 w-4 shrink-0" />
          <span>Assistente Virtual</span>
        </button>
        <PWAInstallButton />
      </div>
    </aside>
  );
};
