import React, { useEffect, useMemo, useRef, useState } from "react";
import html2canvas from "html2canvas";
import QRCode from "qrcode";
import {
  Bot,
  Camera,
  Check,
  Copy,
  Edit3,
  Eye,
  FileDown,
  FileText,
  ListChecks,
  Loader2,
  Mail,
  MessageCircle,
  Plus,
  PlusCircle,
  SlidersHorizontal,
  Trash2,
  X,
} from "lucide-react";
import type {
  CatalogItem,
  ClientItem,
  CompanyProfile,
  DocItem,
  DocumentConfig,
  DocumentType,
} from "../types/gestor";
import { formatarMoeda, gerarPixPayload } from "../utils/pix";
import { compressPhotoToDataUrl } from "../utils/image";
import { SignaturePad } from "./SignaturePad";
import { DocumentExportModal } from "./DocumentExportModal";
import type { ExportFormat } from "./DocumentExportModal";

interface DocumentsTabProps {
  company: CompanyProfile;
  clients: ClientItem[];
  services: CatalogItem[];
  materials: CatalogItem[];
  docItems: DocItem[];
  docConfig: DocumentConfig;
  onUpdateItems: (items: DocItem[]) => void;
  onUpdateConfig: (config: DocumentConfig) => void;
  onOpenAssistant: () => void;
  onNotify: (msg: string, type?: "success" | "error") => void;
}

type DocSubTab = "editor" | "preview";

const A4_WIDTH_PX = 794;
const A4_MIN_HEIGHT_PX = 1123;
const MAX_PHOTOS_PER_ITEM = 4;

interface A4SheetContentProps {
  company: CompanyProfile;
  selectedClient?: ClientItem;
  docConfig: DocumentConfig;
  docItems: DocItem[];
  totals: { srv: number; mat: number; disc: number; total: number };
  todayFormatted: string;
  pixQrDataUrl: string;
  signatureDataUrl: string;
}

const A4SheetContent: React.FC<A4SheetContentProps> = ({
  company,
  selectedClient,
  docConfig,
  docItems,
  totals,
  todayFormatted,
  pixQrDataUrl,
  signatureDataUrl,
}) => {
  const itemsWithPhotos = docItems.filter(
    (it) => Array.isArray(it.photos) && it.photos.length > 0
  );

  return (
    <div
      style={{
        backgroundColor: "#ffffff",
        color: "#0f172a",
        width: `${A4_WIDTH_PX}px`,
        minHeight: `${A4_MIN_HEIGHT_PX}px`,
      }}
      className="p-12 flex flex-col justify-between box-border"
    >
      <div>
        {/* Document Header */}
        <div
          style={{ borderBottom: "2px solid #0f172a" }}
          className="flex justify-between items-start pb-5 mb-6"
        >
          <div className="flex items-center gap-4">
            {company.logo && (
              <img
                src={company.logo}
                alt="Logotipo"
                className="max-h-16 max-w-[140px] object-contain"
              />
            )}
            <div>
              <h2
                style={{ color: "#0284c7" }}
                className="text-xl font-black tracking-tight"
              >
                {company.name || "Nome da Empresa"}
              </h2>
              {company.doc && (
                <p style={{ color: "#475569" }} className="text-xs font-medium">
                  {company.doc}
                </p>
              )}
              {company.contact && (
                <p style={{ color: "#475569" }} className="text-xs font-medium">
                  {company.contact}
                </p>
              )}
              {company.address && (
                <p
                  style={{ color: "#64748b" }}
                  className="text-[11px] font-medium"
                >
                  {company.address}
                </p>
              )}
            </div>
          </div>

          <div className="text-right">
            <h3
              style={{ color: "#0f172a" }}
              className="text-2xl font-black uppercase tracking-wide"
            >
              {docConfig.docType}
            </h3>
            <p
              style={{ color: "#475569" }}
              className="text-xs font-semibold mt-1 tabular-nums"
            >
              Data: {todayFormatted}
            </p>
          </div>
        </div>

        {/* Client Info */}
        <div
          style={{
            border: "1px solid #cbd5e1",
            backgroundColor: "#f8fafc",
          }}
          className="rounded-lg p-3.5 mb-6 text-xs"
        >
          <h4
            style={{
              color: "#334155",
              borderBottom: "1px solid #e2e8f0",
            }}
            className="font-bold uppercase tracking-wider mb-1.5 text-[10px] pb-1"
          >
            Dados do Cliente
          </h4>
          {selectedClient ? (
            <div
              style={{ color: "#1e293b" }}
              className="font-medium leading-relaxed"
            >
              <strong>{selectedClient.name}</strong>
              <br />
              CPF/CNPJ: {selectedClient.doc || "Não informado"} | Tel:{" "}
              {selectedClient.phone || "Não informado"}
              {selectedClient.email ? ` | E-mail: ${selectedClient.email}` : ""}
              <br />
              Endereço: {selectedClient.address || "Não informado"}
            </div>
          ) : (
            <div style={{ color: "#64748b" }}>Nenhum cliente selecionado</div>
          )}
        </div>

        {/* Items Table */}
        <table className="w-full text-xs mb-6 border-collapse">
          <thead>
            <tr style={{ backgroundColor: "#0f172a", color: "#ffffff" }}>
              <th className="p-2.5 text-left rounded-l-md">
                Descrição do Item
              </th>
              <th className="p-2.5 text-center">Tipo</th>
              <th className="p-2.5 text-center">Qtd</th>
              <th className="p-2.5 text-right">Preço Unit.</th>
              <th className="p-2.5 text-right rounded-r-md">Subtotal</th>
            </tr>
          </thead>
          <tbody>
            {docItems.map((item) => {
              const sub = (Number(item.qty) || 0) * (Number(item.price) || 0);
              return (
                <tr
                  key={item.id}
                  style={{ borderBottom: "1px solid #e2e8f0" }}
                >
                  <td className="p-2.5">{item.desc}</td>
                  <td className="p-2.5 text-center">{item.type}</td>
                  <td className="p-2.5 text-center tabular-nums">{item.qty}</td>
                  <td className="p-2.5 text-right tabular-nums">
                    {formatarMoeda(item.price)}
                  </td>
                  <td className="p-2.5 text-right font-bold tabular-nums">
                    {formatarMoeda(sub)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* Totals */}
        <div className="flex justify-end mb-6">
          <div
            style={{
              backgroundColor: "#f8fafc",
              border: "1px solid #e2e8f0",
            }}
            className="w-64 space-y-1.5 text-xs p-3.5 rounded-lg"
          >
            <div style={{ color: "#475569" }} className="flex justify-between">
              <span>Serviços:</span>
              <strong style={{ color: "#0f172a" }} className="tabular-nums">
                {formatarMoeda(totals.srv)}
              </strong>
            </div>
            <div style={{ color: "#475569" }} className="flex justify-between">
              <span>Materiais:</span>
              <strong style={{ color: "#0f172a" }} className="tabular-nums">
                {formatarMoeda(totals.mat)}
              </strong>
            </div>
            <div
              style={{ color: "#e11d48" }}
              className="flex justify-between font-medium"
            >
              <span>Desconto:</span>
              <span className="tabular-nums">
                - {formatarMoeda(totals.disc)}
              </span>
            </div>
            <div
              style={{
                color: "#0f172a",
                borderTop: "1px solid #cbd5e1",
              }}
              className="flex justify-between text-sm font-bold pt-2"
            >
              <span>TOTAL:</span>
              <strong style={{ color: "#0284c7" }} className="tabular-nums">
                {formatarMoeda(totals.total)}
              </strong>
            </div>
          </div>
        </div>

        {/* Payment & Notes */}
        <div
          style={{
            border: "1px solid #cbd5e1",
            backgroundColor: "#f8fafc",
          }}
          className="rounded-lg p-3.5 mb-6 text-xs space-y-1"
        >
          <h4
            style={{
              color: "#334155",
              borderBottom: "1px solid #e2e8f0",
            }}
            className="font-bold uppercase tracking-wider mb-1 text-[10px] pb-1"
          >
            Condições de Pagamento &amp; Observações
          </h4>
          <p>
            <strong>Forma de Pagamento:</strong> {docConfig.payment}
          </p>
          {docConfig.notes && (
            <p style={{ color: "#475569" }} className="mt-1">
              {docConfig.notes}
            </p>
          )}
        </div>

        {/* Registro Fotográfico dos Serviços Executados (até 4 fotos por descrição) */}
        {itemsWithPhotos.length > 0 && (
          <div
            style={{
              border: "1px solid #cbd5e1",
              backgroundColor: "#f8fafc",
            }}
            className="rounded-lg p-4 mb-6 text-xs space-y-4"
          >
            <h4
              style={{
                color: "#334155",
                borderBottom: "1px solid #e2e8f0",
              }}
              className="font-bold uppercase tracking-wider text-[10px] pb-1.5"
            >
              Registro Fotográfico do Serviço Executado
            </h4>

            <div className="space-y-4">
              {itemsWithPhotos.map((item) => (
                <div key={item.id} className="space-y-2">
                  <div
                    style={{ color: "#0f172a" }}
                    className="font-bold text-[11px] flex items-center justify-between"
                  >
                    <span>{item.desc}</span>
                    <span
                      style={{ color: "#64748b" }}
                      className="font-normal text-[10px]"
                    >
                      {item.photos?.length ?? 0} foto(s)
                    </span>
                  </div>
                  <div className="grid grid-cols-4 gap-2.5">
                    {(item.photos ?? []).slice(0, 4).map((photoUrl, pIdx) => (
                      <div
                        key={pIdx}
                        style={{
                          border: "1px solid #cbd5e1",
                          backgroundColor: "#ffffff",
                        }}
                        className="rounded overflow-hidden"
                      >
                        <img
                          src={photoUrl}
                          alt={`${item.desc} - Foto ${pIdx + 1}`}
                          className="w-full h-24 object-cover block"
                        />
                        <div
                          style={{
                            color: "#475569",
                            borderTop: "1px solid #e2e8f0",
                          }}
                          className="px-1.5 py-0.5 text-[9px] text-center font-medium"
                        >
                          Foto {pIdx + 1}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer: Real Scannable Pix QR & Signature */}
      <div
        style={{ borderTop: "1px solid #cbd5e1" }}
        className="grid grid-cols-2 gap-6 pt-6 items-end"
      >
        <div
          style={{
            border: "1px dashed #94a3b8",
            backgroundColor: "#f8fafc",
          }}
          className="rounded-lg p-3 flex items-center gap-3"
        >
          {pixQrDataUrl ? (
            <img
              src={pixQrDataUrl}
              alt="QR Code Pix"
              width={78}
              height={78}
              style={{
                backgroundColor: "#ffffff",
                border: "1px solid #e2e8f0",
              }}
              className="rounded shrink-0"
            />
          ) : (
            <div
              style={{
                width: "78px",
                height: "78px",
                backgroundColor: "#ffffff",
                border: "1px solid #e2e8f0",
              }}
              className="rounded shrink-0"
            />
          )}
          <div className="text-[10px] leading-tight overflow-hidden">
            <strong style={{ color: "#0f172a" }} className="block mb-0.5">
              Pagamento via Pix
            </strong>
            <span
              style={{ color: "#475569" }}
              className="block font-mono text-[9px] truncate"
            >
              {company.pix || "Chave Pix não configurada"}
            </span>
            <span style={{ color: "#64748b" }} className="block mt-0.5">
              Escaneie o QR Code ou utilize a chave.
            </span>
          </div>
        </div>

        <div className="text-center">
          {signatureDataUrl && (
            <img
              src={signatureDataUrl}
              alt="Assinatura digital"
              className="max-h-14 mx-auto mb-1 block object-contain"
            />
          )}
          <div
            style={{
              borderTop: "1px solid #0f172a",
              color: "#1e293b",
            }}
            className="pt-1 w-52 mx-auto text-[11px] font-bold"
          >
            {company.name || "Nome do Profissional / Empresa"}
          </div>
        </div>
      </div>
    </div>
  );
};

export const DocumentsTab: React.FC<DocumentsTabProps> = ({
  company,
  clients,
  services,
  materials,
  docItems,
  docConfig,
  onUpdateItems,
  onUpdateConfig,
  onOpenAssistant,
  onNotify,
}) => {
  const [subTab, setSubTab] = useState<DocSubTab>("editor");
  const [quickServiceId, setQuickServiceId] = useState(
    services[0] ? String(services[0].id) : ""
  );
  const [quickMaterialId, setQuickMaterialId] = useState(
    materials[0] ? String(materials[0].id) : ""
  );
  const [signatureDataUrl, setSignatureDataUrl] = useState("");
  const [isCapturingPreview, setIsCapturingPreview] = useState(false);
  const [copiedPix, setCopiedPix] = useState(false);
  const [pixQrDataUrl, setPixQrDataUrl] = useState("");
  const [expandedPhotosId, setExpandedPhotosId] = useState<string | null>(
    docItems[0]?.id ?? null
  );

  // Responsive A4 fit-to-screen scale on the separate Folha A4 tab
  const previewWrapperRef = useRef<HTMLDivElement | null>(null);
  const previewSheetMeasureRef = useRef<HTMLDivElement | null>(null);
  const [fitScale, setFitScale] = useState(1);
  const [sheetHeight, setSheetHeight] = useState(A4_MIN_HEIGHT_PX);

  // Offscreen crisp 1:1 capture target for html2canvas
  const exportSheetRef = useRef<HTMLDivElement | null>(null);

  // Export Modal state
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState<ExportFormat>("pdf");
  const [exportSnapshot, setExportSnapshot] = useState<{
    dataUrl: string;
    width: number;
    height: number;
  }>({ dataUrl: "", width: 0, height: 0 });

  useEffect(() => {
    if (!quickServiceId && services[0]) {
      setQuickServiceId(String(services[0].id));
    }
  }, [services, quickServiceId]);

  useEffect(() => {
    if (!quickMaterialId && materials[0]) {
      setQuickMaterialId(String(materials[0].id));
    }
  }, [materials, quickMaterialId]);

  const selectedClient = useMemo(
    () =>
      clients.find((c) => String(c.id) === String(docConfig.clientId)) ??
      clients[0],
    [clients, docConfig.clientId]
  );

  const totals = useMemo(() => {
    let srv = 0;
    let mat = 0;
    for (const item of docItems) {
      const sub = (Number(item.qty) || 0) * (Number(item.price) || 0);
      if (item.type === "Serviço") srv += sub;
      else mat += sub;
    }
    const disc = Math.max(0, Number(docConfig.discount) || 0);
    const total = Math.max(0, srv + mat - disc);
    return { srv, mat, disc, total };
  }, [docItems, docConfig.discount]);

  const pixPayload = useMemo(
    () => gerarPixPayload(company.pix, company.name, company.city, totals.total),
    [company.pix, company.name, company.city, totals.total]
  );

  useEffect(() => {
    if (!pixPayload) {
      setPixQrDataUrl("");
      return;
    }
    QRCode.toDataURL(pixPayload, {
      width: 156,
      margin: 1,
      color: { dark: "#0f172a", light: "#ffffff" },
    })
      .then((url) => setPixQrDataUrl(url))
      .catch(() => setPixQrDataUrl(""));
  }, [pixPayload]);

  // Fit-to-screen ResizeObserver for the separate Folha A4 tab
  useEffect(() => {
    if (subTab !== "preview") return;
    const wrapper = previewWrapperRef.current;
    const sheetEl = previewSheetMeasureRef.current;
    if (!wrapper) return;

    const updateScale = () => {
      const cs = getComputedStyle(wrapper);
      const padX =
        (parseFloat(cs.paddingLeft) || 0) + (parseFloat(cs.paddingRight) || 0);
      const availableWidth = Math.max(240, wrapper.clientWidth - padX);
      if (availableWidth > 0) {
        const nextScale = Math.min(1.15, availableWidth / A4_WIDTH_PX);
        setFitScale(nextScale);
      }
      if (sheetEl) {
        setSheetHeight(Math.max(A4_MIN_HEIGHT_PX, sheetEl.scrollHeight));
      }
    };

    updateScale();
    const ro = new ResizeObserver(updateScale);
    ro.observe(wrapper);
    if (sheetEl) ro.observe(sheetEl);
    return () => ro.disconnect();
  }, [subTab, docItems, docConfig, company, signatureDataUrl]);

  function addCatalogItem(kind: "service" | "material") {
    const list = kind === "service" ? services : materials;
    const targetId = kind === "service" ? quickServiceId : quickMaterialId;
    const found = list.find((item) => String(item.id) === targetId) ?? list[0];
    if (!found) {
      onNotify("Nenhum item disponível neste catálogo.", "error");
      return;
    }
    const newId = `doc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    onUpdateItems([
      ...docItems,
      {
        id: newId,
        type: kind === "service" ? "Serviço" : "Material",
        desc: found.name,
        qty: 1,
        price: found.price,
        photos: [],
      },
    ]);
    setExpandedPhotosId(newId);
  }

  function addManualItem(type: "Serviço" | "Material") {
    const newId = `doc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    onUpdateItems([
      ...docItems,
      {
        id: newId,
        type,
        desc:
          type === "Serviço"
            ? "Novo serviço personalizado"
            : "Novo material personalizado",
        qty: 1,
        price: 0,
        photos: [],
      },
    ]);
    setExpandedPhotosId(newId);
  }

  function updateItem(
    id: string,
    field: "desc" | "qty" | "price",
    value: string
  ) {
    onUpdateItems(
      docItems.map((item) => {
        if (item.id !== id) return item;
        if (field === "desc") return { ...item, desc: value };
        return { ...item, [field]: parseFloat(value) || 0 };
      })
    );
  }

  function removeItem(id: string) {
    onUpdateItems(docItems.filter((item) => item.id !== id));
  }

  async function handleAddPhotosToItem(
    itemId: string,
    fileList: FileList | null,
    slotIndex?: number
  ) {
    if (!fileList || fileList.length === 0) return;
    const targetItem = docItems.find((it) => it.id === itemId);
    if (!targetItem) return;

    const currentPhotos = [...(targetItem.photos ?? [])];

    try {
      if (typeof slotIndex === "number") {
        // Replace or fill specific slot
        const compressed = await compressPhotoToDataUrl(fileList[0]);
        if (slotIndex < currentPhotos.length) {
          currentPhotos[slotIndex] = compressed;
        } else {
          currentPhotos.push(compressed);
        }
      } else {
        // Append up to MAX_PHOTOS_PER_ITEM
        const remaining = MAX_PHOTOS_PER_ITEM - currentPhotos.length;
        if (remaining <= 0) {
          onNotify(
            `Limite de ${MAX_PHOTOS_PER_ITEM} fotos atingido para esta descrição.`,
            "error"
          );
          return;
        }
        const filesToProcess = Array.from(fileList).slice(0, remaining);
        for (const f of filesToProcess) {
          const compressed = await compressPhotoToDataUrl(f);
          currentPhotos.push(compressed);
        }
        if (fileList.length > remaining) {
          onNotify(
            `Adicionadas ${filesToProcess.length} fotos (máximo de 4 por descrição).`,
            "success"
          );
        }
      }

      onUpdateItems(
        docItems.map((it) =>
          it.id === itemId
            ? { ...it, photos: currentPhotos.slice(0, MAX_PHOTOS_PER_ITEM) }
            : it
        )
      );
      setExpandedPhotosId(itemId);
    } catch {
      onNotify("Não foi possível carregar uma das fotos selecionadas.", "error");
    }
  }

  function handleRemovePhotoFromItem(itemId: string, photoIdx: number) {
    onUpdateItems(
      docItems.map((it) => {
        if (it.id !== itemId) return it;
        const nextPhotos = (it.photos ?? []).filter((_, idx) => idx !== photoIdx);
        return { ...it, photos: nextPhotos };
      })
    );
  }

  async function handleCopyPix() {
    if (!pixPayload) {
      onNotify("Configure uma Chave Pix em Dados da Empresa primeiro.", "error");
      return;
    }
    try {
      await navigator.clipboard.writeText(pixPayload);
      setCopiedPix(true);
      setTimeout(() => setCopiedPix(false), 1800);
      onNotify("Código Pix Copia e Cola copiado.", "success");
    } catch {
      onNotify("Não foi possível copiar o código Pix.", "error");
    }
  }

  async function openExportModal(initialFmt: ExportFormat = "pdf") {
    const el = exportSheetRef.current;
    if (!el || isCapturingPreview) return;
    setIsCapturingPreview(true);
    try {
      const canvas = await html2canvas(el, {
        scale: 2,
        useCORS: true,
        backgroundColor: "#ffffff",
        logging: false,
      });
      const dataUrl = canvas.toDataURL("image/jpeg", 0.94);
      setExportSnapshot({
        dataUrl,
        width: canvas.width,
        height: canvas.height,
      });
      setExportFormat(initialFmt);
      setExportModalOpen(true);
    } catch {
      onNotify("Erro ao gerar pré-visualização para exportação.", "error");
    } finally {
      setIsCapturingPreview(false);
    }
  }

  const todayFormatted = new Date().toLocaleDateString("pt-BR");

  return (
    <div className="space-y-6">
      {/* Top Action Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <FileText className="h-5 w-5 text-sky-400" />
            <span>Emissão de Documentos</span>
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Adicione até 4 fotos do serviço executado por descrição e confira a
            Folha A4 antes de enviar.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onOpenAssistant}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-sky-500/40 bg-sky-500/15 px-3.5 py-2 text-xs font-bold text-sky-300 transition-colors hover:bg-sky-500/25 cursor-pointer whitespace-nowrap shrink-0"
          >
            <Bot className="h-4 w-4" />
            <span>Assistente de Orçamento</span>
          </button>

          <button
            type="button"
            disabled={isCapturingPreview}
            onClick={() => void openExportModal("pdf")}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-xl bg-sky-500 px-4 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-sky-400 disabled:opacity-60 cursor-pointer whitespace-nowrap shrink-0"
          >
            {isCapturingPreview ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <FileDown className="h-4 w-4" />
            )}
            <span>Salvar PDF / Imagem</span>
          </button>

          <button
            type="button"
            disabled={isCapturingPreview}
            onClick={() => void openExportModal("pdf")}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-bold text-white transition-colors hover:bg-emerald-500 disabled:opacity-60 cursor-pointer whitespace-nowrap shrink-0"
          >
            <MessageCircle className="h-4 w-4" />
            <span>WhatsApp</span>
          </button>

          <button
            type="button"
            disabled={isCapturingPreview}
            onClick={() => void openExportModal("pdf")}
            className="inline-flex min-h-[40px] items-center gap-2 rounded-xl border border-slate-700 bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-200 transition-colors hover:bg-slate-700 disabled:opacity-60 cursor-pointer whitespace-nowrap shrink-0"
          >
            <Mail className="h-4 w-4 text-sky-400" />
            <span>E-mail</span>
          </button>
        </div>
      </div>

      {/* Sub-tabs: Editor vs Folha A4 (Separate Screen-Fitted Tab) */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div
          role="tablist"
          aria-label="Modo de visualização do documento"
          className="inline-flex items-center gap-1 rounded-xl border border-slate-800 bg-[#030712] p-1"
        >
          <button
            type="button"
            role="tab"
            aria-selected={subTab === "editor"}
            onClick={() => setSubTab("editor")}
            className={`min-h-[38px] inline-flex items-center gap-2 rounded-lg px-4 py-1.5 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === "editor"
                ? "bg-sky-500 text-slate-950"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Edit3 className="h-3.5 w-3.5" />
            <span>Editor do Orçamento</span>
          </button>

          <button
            type="button"
            role="tab"
            aria-selected={subTab === "preview"}
            onClick={() => setSubTab("preview")}
            className={`min-h-[38px] inline-flex items-center gap-2 rounded-lg px-4 py-1.5 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              subTab === "preview"
                ? "bg-sky-500 text-slate-950"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Eye className="h-3.5 w-3.5" />
            <span>Folha A4 (Pré-visualização)</span>
          </button>
        </div>

        {/* Dark-mode Compact Totals Strip */}
        <div className="flex flex-wrap items-center gap-4 text-xs">
          <span className="text-slate-400">
            Serviços:{" "}
            <strong className="font-mono text-slate-200 tabular-nums">
              {formatarMoeda(totals.srv)}
            </strong>
          </span>
          <span className="text-slate-400">
            Materiais:{" "}
            <strong className="font-mono text-slate-200 tabular-nums">
              {formatarMoeda(totals.mat)}
            </strong>
          </span>
          <span className="text-slate-400">
            Total:{" "}
            <strong className="font-mono text-sm text-sky-400 tabular-nums">
              {formatarMoeda(totals.total)}
            </strong>
          </span>
        </div>
      </div>

      {/* TAB 1: EDITOR DO ORÇAMENTO (100% DARK MODE — SEM PARTES BRANCAS) */}
      {subTab === "editor" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Document Config */}
            <section className="rounded-2xl border border-slate-800 bg-[#0f172a] p-5 space-y-4">
              <h2 className="flex items-center gap-2 border-b border-slate-800 pb-2.5 text-xs font-bold uppercase tracking-wider text-slate-300">
                <SlidersHorizontal className="h-4 w-4 text-sky-400" />
                <span>Configuração do Documento</span>
              </h2>

              <div>
                <label
                  htmlFor="doc-type"
                  className="mb-1.5 block text-xs font-semibold text-slate-400"
                >
                  Tipo de Documento
                </label>
                <select
                  id="doc-type"
                  value={docConfig.docType}
                  onChange={(e) =>
                    onUpdateConfig({
                      ...docConfig,
                      docType: e.target.value as DocumentType,
                    })
                  }
                  className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
                >
                  <option value="ORÇAMENTO">Orçamento Técnico</option>
                  <option value="NOTA DE SERVIÇO">Nota de Serviço</option>
                  <option value="RECIBO DE PAGAMENTO">
                    Recibo de Pagamento
                  </option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="doc-client"
                  className="mb-1.5 block text-xs font-semibold text-slate-400"
                >
                  Cliente Destinatário
                </label>
                <select
                  id="doc-client"
                  value={selectedClient ? String(selectedClient.id) : ""}
                  onChange={(e) =>
                    onUpdateConfig({ ...docConfig, clientId: e.target.value })
                  }
                  className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
                >
                  {clients.length === 0 ? (
                    <option value="">Nenhum cliente cadastrado</option>
                  ) : (
                    clients.map((c) => (
                      <option key={c.id} value={String(c.id)}>
                        {c.name}
                      </option>
                    ))
                  )}
                </select>
              </div>

              <div>
                <label
                  htmlFor="doc-payment"
                  className="mb-1.5 block text-xs font-semibold text-slate-400"
                >
                  Forma de Pagamento
                </label>
                <select
                  id="doc-payment"
                  value={docConfig.payment}
                  onChange={(e) =>
                    onUpdateConfig({ ...docConfig, payment: e.target.value })
                  }
                  className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
                >
                  <option value="Pix (Pagamento Instantâneo)">
                    Pix (Pagamento Instantâneo)
                  </option>
                  <option value="Dinheiro / Espécie">Dinheiro / Espécie</option>
                  <option value="Cartão de Crédito">Cartão de Crédito</option>
                  <option value="Cartão de Débito">Cartão de Débito</option>
                  <option value="Boleto Bancário">Boleto Bancário</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="doc-discount"
                  className="mb-1.5 block text-xs font-semibold text-slate-400"
                >
                  Desconto Geral (R$)
                </label>
                <input
                  id="doc-discount"
                  type="number"
                  step="0.01"
                  value={docConfig.discount}
                  onChange={(e) =>
                    onUpdateConfig({
                      ...docConfig,
                      discount: parseFloat(e.target.value) || 0,
                    })
                  }
                  className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm font-mono tabular-nums text-white focus:border-sky-500 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="doc-notes"
                  className="mb-1.5 block text-xs font-semibold text-slate-400"
                >
                  Observações / Normas Técnicas
                </label>
                <textarea
                  id="doc-notes"
                  rows={3}
                  value={docConfig.notes}
                  onChange={(e) =>
                    onUpdateConfig({ ...docConfig, notes: e.target.value })
                  }
                  className="w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2.5 text-sm text-white focus:border-sky-500 focus:outline-none"
                />
              </div>
            </section>

            {/* Items Composition, 4-Photo Execution Slots per Description & Signature */}
            <section className="rounded-2xl border border-slate-800 bg-[#0f172a] p-5 lg:col-span-2 flex flex-col justify-between gap-5">
              <div className="space-y-4">
                <h2 className="flex items-center gap-2 border-b border-slate-800 pb-2.5 text-xs font-bold uppercase tracking-wider text-slate-300">
                  <ListChecks className="h-4 w-4 text-sky-400" />
                  <span>Composição de Itens &amp; Fotos do Serviço (até 4 por descrição)</span>
                </h2>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label
                      htmlFor="quick-srv"
                      className="mb-1.5 block text-xs font-semibold text-slate-400"
                    >
                      Adicionar Mão de Obra / Serviço
                    </label>
                    <div className="flex gap-2">
                      <select
                        id="quick-srv"
                        value={quickServiceId}
                        onChange={(e) => setQuickServiceId(e.target.value)}
                        className="min-h-[40px] flex-1 rounded-xl border border-slate-800 bg-[#07090e] px-3 py-2 text-xs text-white"
                      >
                        {services.map((s) => (
                          <option key={s.id} value={String(s.id)}>
                            {s.name} ({formatarMoeda(s.price)})
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        aria-label="Adicionar serviço selecionado"
                        onClick={() => addCatalogItem("service")}
                        className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl bg-sky-500 text-slate-950 hover:bg-sky-400 cursor-pointer"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  <div>
                    <label
                      htmlFor="quick-mat"
                      className="mb-1.5 block text-xs font-semibold text-slate-400"
                    >
                      Adicionar Material da Pasta
                    </label>
                    <div className="flex gap-2">
                      <select
                        id="quick-mat"
                        value={quickMaterialId}
                        onChange={(e) => setQuickMaterialId(e.target.value)}
                        className="min-h-[40px] flex-1 rounded-xl border border-slate-800 bg-[#07090e] px-3 py-2 text-xs text-white"
                      >
                        {materials.map((m) => (
                          <option key={m.id} value={String(m.id)}>
                            {m.name} ({formatarMoeda(m.price)})
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        aria-label="Adicionar material selecionado"
                        onClick={() => addCatalogItem("material")}
                        className="inline-flex min-h-[40px] min-w-[40px] items-center justify-center rounded-xl bg-sky-500 text-slate-950 hover:bg-sky-400 cursor-pointer"
                      >
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => addManualItem("Serviço")}
                    className="inline-flex min-h-[36px] items-center gap-1.5 text-xs font-semibold text-sky-400 hover:text-sky-300 cursor-pointer"
                  >
                    <PlusCircle className="h-3.5 w-3.5" />
                    <span>Novo Serviço Manual</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => addManualItem("Material")}
                    className="inline-flex min-h-[36px] items-center gap-1.5 text-xs font-semibold text-emerald-400 hover:text-emerald-300 cursor-pointer"
                  >
                    <PlusCircle className="h-3.5 w-3.5" />
                    <span>Novo Material Manual</span>
                  </button>
                </div>

                {/* Items List with Inline 4-Photo Strip per Description */}
                <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1">
                  {docItems.length === 0 ? (
                    <div className="rounded-xl border border-slate-800 bg-[#07090e] p-6 text-center text-xs text-slate-500">
                      Adicione serviços ou materiais acima ou peça ao Assistente
                      de Orçamento.
                    </div>
                  ) : (
                    docItems.map((item) => {
                      const photos = item.photos ?? [];
                      const isPhotosOpen =
                        expandedPhotosId === item.id || photos.length > 0;

                      return (
                        <div
                          key={item.id}
                          className="rounded-xl border border-slate-800 bg-[#07090e] p-3.5 space-y-3"
                        >
                          <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center">
                            <div className="sm:col-span-2 flex items-center justify-between sm:block">
                              <span
                                className={`text-xs font-semibold ${
                                  item.type === "Serviço"
                                    ? "text-sky-400"
                                    : "text-emerald-400"
                                }`}
                              >
                                {item.type}
                              </span>
                            </div>

                            <div className="sm:col-span-4">
                              <input
                                type="text"
                                aria-label="Descrição do item"
                                value={item.desc}
                                onChange={(e) =>
                                  updateItem(item.id, "desc", e.target.value)
                                }
                                className="w-full rounded-lg border border-slate-800 bg-[#0f172a] px-2.5 py-1.5 text-xs text-white focus:border-sky-500 focus:outline-none"
                              />
                            </div>

                            <div className="sm:col-span-2">
                              <input
                                type="number"
                                step="0.1"
                                aria-label="Quantidade"
                                value={item.qty}
                                onChange={(e) =>
                                  updateItem(item.id, "qty", e.target.value)
                                }
                                className="w-full rounded-lg border border-slate-800 bg-[#0f172a] px-2 py-1.5 text-center font-mono text-xs tabular-nums text-white focus:border-sky-500 focus:outline-none"
                              />
                            </div>

                            <div className="sm:col-span-2">
                              <input
                                type="number"
                                step="0.01"
                                aria-label="Valor unitário"
                                value={item.price}
                                onChange={(e) =>
                                  updateItem(item.id, "price", e.target.value)
                                }
                                className="w-full rounded-lg border border-slate-800 bg-[#0f172a] px-2 py-1.5 text-right font-mono text-xs tabular-nums text-white focus:border-sky-500 focus:outline-none"
                              />
                            </div>

                            <div className="sm:col-span-2 flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() =>
                                  setExpandedPhotosId((curr) =>
                                    curr === item.id ? null : item.id
                                  )
                                }
                                title="Fotos do serviço executado"
                                className={`inline-flex h-8 items-center gap-1 rounded-lg border px-2 text-[11px] font-medium cursor-pointer ${
                                  photos.length > 0
                                    ? "border-sky-500/40 bg-sky-500/10 text-sky-300"
                                    : "border-slate-800 bg-[#0f172a] text-slate-400 hover:text-white"
                                }`}
                              >
                                <Camera className="h-3.5 w-3.5" />
                                <span className="font-mono tabular-nums">
                                  {photos.length}/4
                                </span>
                              </button>

                              <button
                                type="button"
                                aria-label={`Remover ${item.desc}`}
                                onClick={() => removeItem(item.id)}
                                className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:bg-rose-500/10 hover:text-rose-400 cursor-pointer"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>

                          {/* 4 Photo Slots per Description */}
                          {isPhotosOpen && (
                            <div className="border-t border-slate-800/80 pt-3">
                              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                                <span className="text-[11px] font-medium text-slate-400">
                                  Fotos do serviço executado ({photos.length}/4)
                                </span>
                                {photos.length < MAX_PHOTOS_PER_ITEM && (
                                  <label className="inline-flex items-center gap-1 text-[11px] font-semibold text-sky-400 hover:text-sky-300 cursor-pointer">
                                    <Plus className="h-3 w-3" />
                                    <span>Adicionar várias fotos</span>
                                    <input
                                      type="file"
                                      accept="image/*"
                                      multiple
                                      onChange={(e) => {
                                        void handleAddPhotosToItem(
                                          item.id,
                                          e.target.files
                                        );
                                        e.target.value = "";
                                      }}
                                      className="hidden"
                                    />
                                  </label>
                                )}
                              </div>

                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                                {Array.from({ length: MAX_PHOTOS_PER_ITEM }).map(
                                  (_, slotIdx) => {
                                    const photoSrc = photos[slotIdx];
                                    return (
                                      <div
                                        key={slotIdx}
                                        className="relative aspect-[4/3] overflow-hidden rounded-lg border border-slate-800 bg-[#0f172a]"
                                      >
                                        {photoSrc ? (
                                          <>
                                            <img
                                              src={photoSrc}
                                              alt={`${item.desc} - Foto ${slotIdx + 1}`}
                                              className="h-full w-full object-cover"
                                            />
                                            <button
                                              type="button"
                                              aria-label={`Remover foto ${slotIdx + 1}`}
                                              onClick={() =>
                                                handleRemovePhotoFromItem(
                                                  item.id,
                                                  slotIdx
                                                )
                                              }
                                              className="absolute right-1.5 top-1.5 inline-flex h-6 w-6 items-center justify-center rounded-md bg-black/75 text-slate-200 hover:bg-rose-600 cursor-pointer"
                                            >
                                              <X className="h-3.5 w-3.5" />
                                            </button>
                                            <span className="absolute bottom-1 left-1.5 rounded bg-black/70 px-1.5 py-0.5 text-[10px] font-medium text-slate-200">
                                              Foto {slotIdx + 1}
                                            </span>
                                          </>
                                        ) : (
                                          <label className="flex h-full w-full flex-col items-center justify-center gap-1 text-slate-500 hover:bg-slate-900 hover:text-sky-400 transition-colors cursor-pointer">
                                            <Camera className="h-4 w-4" />
                                            <span className="text-[10px] font-medium">
                                              Foto {slotIdx + 1}
                                            </span>
                                            <input
                                              type="file"
                                              accept="image/*"
                                              onChange={(e) => {
                                                void handleAddPhotosToItem(
                                                  item.id,
                                                  e.target.files,
                                                  slotIdx
                                                );
                                                e.target.value = "";
                                              }}
                                              className="hidden"
                                            />
                                          </label>
                                        )}
                                      </div>
                                    );
                                  }
                                )}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              <SignaturePad
                signatureDataUrl={signatureDataUrl}
                onChange={setSignatureDataUrl}
              />
            </section>
          </div>

          {/* Dark-mode Pix & Preview CTA Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-800 bg-[#0f172a] px-5 py-4">
            <div className="min-w-0 flex-1">
              {pixPayload ? (
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="font-semibold text-slate-300">
                    Pix Copia e Cola:
                  </span>
                  <span className="font-mono text-slate-400 truncate max-w-md">
                    {pixPayload}
                  </span>
                  <button
                    type="button"
                    onClick={() => void handleCopyPix()}
                    className="inline-flex items-center gap-1 rounded-lg border border-slate-700 bg-slate-800 px-2.5 py-1 text-[11px] font-semibold text-slate-200 hover:bg-slate-700 cursor-pointer"
                  >
                    {copiedPix ? (
                      <>
                        <Check className="h-3 w-3 text-emerald-400" />
                        <span>Copiado</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3" />
                        <span>Copiar</span>
                      </>
                    )}
                  </button>
                </div>
              ) : (
                <span className="text-xs text-slate-400">
                  Configure uma Chave Pix em Dados da Empresa para gerar o QR
                  Code no documento.
                </span>
              )}
            </div>

            <button
              type="button"
              onClick={() => setSubTab("preview")}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-xl bg-sky-500 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-sky-400 cursor-pointer whitespace-nowrap"
            >
              <Eye className="h-4 w-4" />
              <span>Ver Folha A4 Ajustada à Tela</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 2: FOLHA A4 SEPARADA E AJUSTADA AO TAMANHO DA TELA */}
      {subTab === "preview" && (
        <div className="space-y-4">
          <div
            ref={previewWrapperRef}
            className="w-full overflow-hidden rounded-2xl border border-slate-800 bg-[#030712] p-3 sm:p-6 flex justify-center"
          >
            <div
              style={{
                width: `${Math.round(A4_WIDTH_PX * fitScale)}px`,
                height: `${Math.round(sheetHeight * fitScale)}px`,
                position: "relative",
              }}
            >
              <div
                id="a4Sheet"
                ref={previewSheetMeasureRef}
                style={{
                  width: `${A4_WIDTH_PX}px`,
                  transform: `scale(${fitScale})`,
                  transformOrigin: "top left",
                }}
                className="rounded-lg overflow-hidden shadow-2xl"
              >
                <A4SheetContent
                  company={company}
                  selectedClient={selectedClient}
                  docConfig={docConfig}
                  docItems={docItems}
                  totals={totals}
                  todayFormatted={todayFormatted}
                  pixQrDataUrl={pixQrDataUrl}
                  signatureDataUrl={signatureDataUrl}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Offscreen crisp 1:1 A4 capture target so Export/WhatsApp/Email work from any tab */}
      <div
        aria-hidden="true"
        style={{
          position: "fixed",
          left: "-99999px",
          top: 0,
          pointerEvents: "none",
        }}
      >
        <div ref={exportSheetRef}>
          <A4SheetContent
            company={company}
            selectedClient={selectedClient}
            docConfig={docConfig}
            docItems={docItems}
            totals={totals}
            todayFormatted={todayFormatted}
            pixQrDataUrl={pixQrDataUrl}
            signatureDataUrl={signatureDataUrl}
          />
        </div>
      </div>

      {/* Pre-save & Send Preview Modal */}
      <DocumentExportModal
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
        previewImageDataUrl={exportSnapshot.dataUrl}
        previewWidth={exportSnapshot.width}
        previewHeight={exportSnapshot.height}
        initialFormat={exportFormat}
        company={company}
        client={selectedClient}
        docConfig={docConfig}
        totalAmount={totals.total}
        pixPayload={pixPayload}
        onNotify={onNotify}
      />
    </div>
  );
};
