import React, { useMemo, useState } from "react";
import { CalendarDays, CheckCircle2, Clock, Plus, Trash2, XCircle } from "lucide-react";
import type { AgendaEntry, AgendaStatus, ClientItem } from "../types/gestor";

interface AgendaTabProps {
  agenda: AgendaEntry[];
  clients: ClientItem[];
  onAdd: (entry: AgendaEntry) => void;
  onUpdateStatus: (id: number, status: AgendaStatus) => void;
  onDelete: (id: number) => void;
  onNotify: (msg: string, type?: "success" | "error") => void;
}

const STATUS_OPTIONS: AgendaStatus[] = [
  "Agendado",
  "Em Andamento",
  "Concluído",
  "Cancelado",
];

function formatDateTimePtBr(val: string): string {
  if (!val) return "-";
  const d = new Date(val);
  if (Number.isNaN(d.getTime())) return val;
  return d.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export const AgendaTab: React.FC<AgendaTabProps> = ({
  agenda,
  clients,
  onAdd,
  onUpdateStatus,
  onDelete,
  onNotify,
}) => {
  const [clientId, setClientId] = useState(
    clients[0] ? String(clients[0].id) : ""
  );
  const [date, setDate] = useState("");
  const [desc, setDesc] = useState("");
  const [filterStatus, setFilterStatus] = useState<"Todos" | AgendaStatus>(
    "Todos"
  );

  const filteredAgenda = useMemo(() => {
    const sorted = [...agenda].sort((a, b) => a.date.localeCompare(b.date));
    if (filterStatus === "Todos") return sorted;
    return sorted.filter((item) => item.status === filterStatus);
  }, [agenda, filterStatus]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!date || !desc.trim()) {
      onNotify("Preencha a data/hora e a descrição do atendimento.", "error");
      return;
    }
    onAdd({
      id: Date.now(),
      clientId: clientId || (clients[0] ? String(clients[0].id) : ""),
      date,
      desc: desc.trim(),
      status: "Agendado",
    });
    setDesc("");
    onNotify("Atendimento agendado com sucesso.", "success");
  }

  function renderStatusLabel(status: AgendaStatus) {
    switch (status) {
      case "Concluído":
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-400">
            <CheckCircle2 className="h-3.5 w-3.5" />
            <span>Concluído</span>
          </span>
        );
      case "Em Andamento":
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-sky-400">
            <Clock className="h-3.5 w-3.5" />
            <span>Em Andamento</span>
          </span>
        );
      case "Cancelado":
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-400">
            <XCircle className="h-3.5 w-3.5" />
            <span>Cancelado</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-400">
            <Clock className="h-3.5 w-3.5" />
            <span>Agendado</span>
          </span>
        );
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            <CalendarDays className="h-5 w-5 text-sky-400" />
            <span>Agenda Técnica</span>
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Agende visitas técnicas, manutenções e acompanhe o andamento dos
            atendimentos.
          </p>
        </div>
      </div>

      {/* Form */}
      <form
        onSubmit={handleSubmit}
        className="rounded-2xl border border-slate-800 bg-[#0f172a] p-5"
      >
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div>
            <label
              htmlFor="ag-client"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Cliente
            </label>
            <select
              id="ag-client"
              value={clientId}
              onChange={(e) => setClientId(e.target.value)}
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
            >
              {clients.length === 0 ? (
                <option value="">Nenhum cliente cadastrado</option>
              ) : (
                clients.map((c) => (
                  <option key={c.id} value={String(c.id)}>
                    {c.name}
                  </option>
                ))
              )}
            </select>
          </div>

          <div>
            <label
              htmlFor="ag-date"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Data e Hora
            </label>
            <input
              id="ag-date"
              type="datetime-local"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white focus:border-sky-500 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="ag-desc"
              className="mb-1.5 block text-xs font-semibold text-slate-400"
            >
              Serviço / Atendimento
            </label>
            <input
              id="ag-desc"
              type="text"
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              placeholder="Ex: Manutenção preventiva"
              className="min-h-[42px] w-full rounded-xl border border-slate-800 bg-[#07090e] px-3.5 py-2 text-sm text-white placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-4 flex justify-end">
          <button
            type="submit"
            className="inline-flex min-h-[42px] items-center gap-2 rounded-xl bg-sky-500 px-5 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-sky-400 cursor-pointer whitespace-nowrap"
          >
            <Plus className="h-4 w-4" />
            <span>Agendar Atendimento</span>
          </button>
        </div>
      </form>

      {/* Filter Bar + Table */}
      <div className="rounded-2xl border border-slate-800 bg-[#0f172a] p-5 space-y-4">
        <div
          role="group"
          aria-label="Filtrar agenda por status"
          className="flex flex-wrap items-center gap-1.5"
        >
          {(["Todos", ...STATUS_OPTIONS] as const).map((status) => {
            const active = filterStatus === status;
            return (
              <button
                key={status}
                type="button"
                onClick={() => setFilterStatus(status)}
                className={`min-h-[36px] rounded-lg px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  active
                    ? "bg-sky-500 text-slate-950 font-semibold"
                    : "bg-slate-900 text-slate-400 hover:text-white"
                }`}
              >
                {status}
              </button>
            );
          })}
        </div>

        {filteredAgenda.length === 0 ? (
          <div className="border-t border-slate-800 py-10 text-center">
            <p className="text-sm font-medium text-slate-300">
              Nenhum atendimento encontrado
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Preencha o formulário acima para agendar sua próxima visita
              técnica.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-y border-slate-800 bg-[#030712] text-xs text-slate-400">
                <tr>
                  <th className="px-3.5 py-3">Data / Hora</th>
                  <th className="px-3.5 py-3">Cliente</th>
                  <th className="px-3.5 py-3">Descrição</th>
                  <th className="px-3.5 py-3">Status</th>
                  <th className="px-3.5 py-3 text-right">Alterar Status</th>
                  <th className="px-3.5 py-3 text-center">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80">
                {filteredAgenda.map((item) => {
                  const clientName =
                    clients.find((c) => String(c.id) === String(item.clientId))
                      ?.name ?? "Cliente";

                  return (
                    <tr
                      key={item.id}
                      className="hover:bg-slate-900/50 transition-colors"
                    >
                      <td className="px-3.5 py-3 font-mono text-xs text-slate-300 tabular-nums whitespace-nowrap">
                        {formatDateTimePtBr(item.date)}
                      </td>
                      <td className="px-3.5 py-3 font-semibold text-white">
                        {clientName}
                      </td>
                      <td className="px-3.5 py-3 text-slate-300">
                        {item.desc}
                      </td>
                      <td className="px-3.5 py-3 whitespace-nowrap">
                        {renderStatusLabel(item.status)}
                      </td>
                      <td className="px-3.5 py-3 text-right">
                        <select
                          aria-label={`Status de ${item.desc}`}
                          value={item.status}
                          onChange={(e) =>
                            onUpdateStatus(
                              item.id,
                              e.target.value as AgendaStatus
                            )
                          }
                          className="rounded-lg border border-slate-700 bg-[#07090e] px-2.5 py-1.5 text-xs text-slate-200 focus:border-sky-500 focus:outline-none"
                        >
                          {STATUS_OPTIONS.map((opt) => (
                            <option key={opt} value={opt}>
                              {opt}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="px-3.5 py-3 text-center">
                        <button
                          type="button"
                          aria-label={`Excluir agendamento ${item.desc}`}
                          onClick={() => onDelete(item.id)}
                          className="inline-flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 transition-colors hover:bg-rose-500/10 hover:text-rose-400 cursor-pointer"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
